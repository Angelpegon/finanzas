<?php $__env->startSection('content'); ?>
<div class="auth-card__intro">
    <p class="auth-card__kicker">Iniciar sesión</p>
    <h2 class="auth-card__title">Bienvenido de nuevo</h2>
    <p class="auth-card__lead">Entra para ver tu situación y registrar movimientos.</p>
</div>
<form method="POST" action="<?php echo e(route('auth.login')); ?>" class="auth-form" novalidate>
    <?php echo csrf_field(); ?>
    <div class="auth-field">
        <label for="email" class="form-label">Correo electrónico</label>
        <input id="email" name="email" type="email" value="<?php echo e(old('email')); ?>" class="form-control form-control-lg <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" autocomplete="email" required autofocus>
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="auth-field">
        <label for="password" class="form-label">Contraseña</label>
        <input id="password" name="password" type="password" class="form-control form-control-lg <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" autocomplete="current-password" required>
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="invalid-feedback"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
    <div class="auth-field auth-field--inline">
        <div class="form-check">
            <input id="remember" name="remember" type="checkbox" value="1" class="form-check-input">
            <label for="remember" class="form-check-label">Mantener sesión iniciada</label>
        </div>
    </div>
    <div class="auth-actions">
        <button class="btn btn-primary btn-lg w-100" type="submit">Ingresar</button>
    </div>
</form>
<p class="auth-card__footer">¿Aún no tienes cuenta? <a href="<?php echo e(route('register')); ?>">Crear cuenta</a></p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', ['title' => 'Iniciar sesión'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/angelpenaloza/Documents/GitHub/finanzas/resources/views/auth/login.blade.php ENDPATH**/ ?>