<?php
    $bagName = $bag ?? 'default';
    $bagErrors = $errors->getBag($bagName);
?>
<?php if($bagErrors->any()): ?>
    <div class="alert alert-danger py-2 px-3 mb-3" role="alert">
        <?php if($bagErrors->has('form')): ?>
            <?php echo e($bagErrors->first('form')); ?>

        <?php else: ?>
            Revisa los campos marcados en este formulario.
        <?php endif; ?>
    </div>
<?php endif; ?>
<?php /**PATH /Users/angelpenaloza/Documents/GitHub/finanzas/resources/views/layouts/partials/form-errors.blade.php ENDPATH**/ ?>