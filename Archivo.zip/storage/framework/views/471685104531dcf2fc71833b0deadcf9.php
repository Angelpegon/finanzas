<?php
    $eyebrow = $eyebrow ?? null;
    $heading = $heading ?? '';
    $subtitle = $subtitle ?? null;
    $backUrl = $backUrl ?? null;
    $backLabel = $backLabel ?? 'Volver';
    $actionUrl = $actionUrl ?? null;
    $actionLabel = $actionLabel ?? 'Nuevo';
?>
<header class="page-intro">
    <?php if($backUrl): ?>
        <a href="<?php echo e($backUrl); ?>" class="back-link">
            <?php echo $__env->make('layouts.partials.icon', ['name' => 'chevron-left', 'class' => 'ui-icon ui-icon--xs'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo e($backLabel); ?>

        </a>
    <?php endif; ?>
    <div class="page-intro__row">
        <div class="page-intro__copy">
            <?php if($eyebrow): ?>
                <p class="eyebrow mb-2"><?php echo e($eyebrow); ?></p>
            <?php endif; ?>
            <h1 class="display-title mb-1"><?php echo e($heading); ?></h1>
            <?php if($subtitle): ?>
                <p class="text-secondary mb-0"><?php echo e($subtitle); ?></p>
            <?php endif; ?>
        </div>
        <?php if($actionUrl): ?>
            <a class="add-button" href="<?php echo e($actionUrl); ?>" aria-label="<?php echo e($actionLabel); ?>">
                <?php echo $__env->make('layouts.partials.icon', ['name' => 'plus', 'class' => 'ui-icon'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </a>
        <?php endif; ?>
    </div>
</header>
<?php /**PATH /Users/angelpenaloza/Documents/GitHub/finanzas/resources/views/layouts/partials/page-intro.blade.php ENDPATH**/ ?>