<?php
    $saldo = (int) $cuenta->saldo_actual_centavos;
?>
<form method="POST" action="<?php echo e(route('app.cuentas.cancelar', $cuenta)); ?>" class="cancel-account" novalidate
    data-swal-confirm
    data-swal-title="¿Cancelar esta cuenta?"
    data-swal-text="<?php echo e($saldo > 0 ? 'Se aplicará la opción elegida sobre el saldo y la cuenta quedará cancelada.' : 'La cuenta dejará de estar disponible. El historial no se borra.'); ?>"
    data-swal-icon="warning"
    data-swal-confirm-text="Cancelar cuenta">
    <?php echo csrf_field(); ?>
    <p class="small text-secondary mb-2">
        Cancelar es permanente: la cuenta deja de usarse. El historial del libro se conserva.
    </p>
    <?php if($saldo > 0): ?>
        <p class="small mb-2">Saldo actual: <strong><?php echo \App\Support\Dinero::formatear($saldo); ?></strong>. Elige qué hacer con ese dinero:</p>
        <div class="vstack gap-2 mb-2">
            <label class="form-check">
                <input class="form-check-input" type="radio" name="disposicion" value="transferir" <?php if(old('disposicion', 'transferir') === 'transferir'): echo 'checked'; endif; ?> required>
                <span class="form-check-label">Transferir a otra cuenta</span>
            </label>
            <?php if($destinos->isNotEmpty()): ?>
                <select name="cuenta_destino_id" class="form-select form-select-sm">
                    <option value="">Cuenta destino</option>
                    <?php $__currentLoopData = $destinos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $destino): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($destino->id); ?>" <?php if(old('cuenta_destino_id') == $destino->id): echo 'selected'; endif; ?>><?php echo e($destino->nombre); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            <?php else: ?>
                <p class="small text-danger mb-0">Necesitas otra cuenta activa para transferir. Crea una o elige baja.</p>
            <?php endif; ?>
            <label class="form-check">
                <input class="form-check-input" type="radio" name="disposicion" value="baja" <?php if(old('disposicion') === 'baja'): echo 'checked'; endif; ?>>
                <span class="form-check-label">Dar de baja el saldo (sale del disponible)</span>
            </label>
        </div>
    <?php endif; ?>
    <button class="card-btn card-btn--danger" type="submit">
        <?php echo $__env->make('layouts.partials.icon', ['name' => 'trash', 'class' => 'ui-icon ui-icon--xs'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        Confirmar cancelación
    </button>
</form>
<?php /**PATH /Users/angelpenaloza/Documents/GitHub/finanzas/resources/views/cuentas/partials/cancelar-form.blade.php ENDPATH**/ ?>