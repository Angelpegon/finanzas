<?php $__env->startSection('content'); ?>
<?php
    $diaCarbon = \Carbon\Carbon::parse($diaSeleccionado)->locale('es');
    $etiquetaDia = ucfirst($diaCarbon->isoFormat('dddd D [de] MMMM'));
?>

<div class="cal-page">
    <div class="cal-toolbar dash-card">
        <div class="cal-toolbar__nav">
            <a class="cal-nav-btn" href="<?php echo e(route('app.calendario', ['anio' => $mesAnterior->year, 'mes' => $mesAnterior->month])); ?>" aria-label="Mes anterior">‹</a>
            <div class="cal-toolbar__title">
                <strong><?php echo e($grilla['etiqueta']); ?></strong>
                <?php if (! ($esMesActual)): ?>
                    <a class="cal-today-link" href="<?php echo e(route('app.calendario')); ?>">Hoy</a>
                <?php endif; ?>
            </div>
            <a class="cal-nav-btn" href="<?php echo e(route('app.calendario', ['anio' => $mesSiguiente->year, 'mes' => $mesSiguiente->month])); ?>" aria-label="Mes siguiente">›</a>
        </div>
        <div class="cal-summary">
            <div class="cal-summary__item cal-summary__item--danger">
                <span>Vencidos</span>
                <strong><?php echo e($resumen['vencidos']); ?></strong>
            </div>
            <div class="cal-summary__item cal-summary__item--accent">
                <span>Proyectados</span>
                <strong><?php echo e($resumen['proyectados']); ?></strong>
            </div>
            <div class="cal-summary__item cal-summary__item--ok">
                <span>Reales</span>
                <strong><?php echo e($resumen['reales']); ?></strong>
            </div>
        </div>
        <div class="cal-summary cal-summary--money">
            <div class="cal-summary__item">
                <span>Ingresos del mes</span>
                <strong class="text-success"><?php echo \App\Support\Dinero::formatear($resumen['ingresos_centavos']); ?></strong>
            </div>
            <div class="cal-summary__item">
                <span>Salidas del mes</span>
                <strong><?php echo \App\Support\Dinero::formatear($resumen['salidas_centavos']); ?></strong>
            </div>
        </div>
    </div>

    <div class="cal-layout">
        <section class="cal-month dash-card" aria-label="Grilla del mes">
            <div class="cal-month__weekdays">
                <?php $__currentLoopData = ['L','M','X','J','V','S','D']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span><?php echo e($wd); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="cal-month__grid">
                <?php $__currentLoopData = $grilla['celdas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $celda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($celda === null): ?>
                        <div class="cal-day cal-day--empty" aria-hidden="true"></div>
                    <?php else: ?>
                        <?php
                            $seleccionado = $celda['fecha'] === $diaSeleccionado;
                            $clases = collect([
                                'cal-day',
                                $celda['hoy'] ? 'is-today' : null,
                                $seleccionado ? 'is-selected' : null,
                                $celda['tiene_pago'] ? 'has-pago' : null,
                                $celda['tiene_ingreso'] ? 'has-ingreso' : null,
                                ($celda['tiene_vencido'] ?? false) ? 'has-vencido' : null,
                                count($celda['eventos']) > 0 ? 'has-events' : null,
                            ])->filter()->implode(' ');
                        ?>
                        <a
                            class="<?php echo e($clases); ?>"
                            href="<?php echo e(route('app.calendario', ['anio' => $fecha->year, 'mes' => $fecha->month, 'dia' => $celda['fecha']])); ?>"
                            <?php if($seleccionado): ?> aria-current="date" <?php endif; ?>
                            title="<?php echo e(collect($celda['eventos'])->pluck('descripcion')->join(' · ') ?: 'Sin eventos'); ?>"
                        >
                            <span class="cal-day__num"><?php echo e($celda['dia']); ?></span>
                            <?php if(count($celda['eventos']) > 0): ?>
                                <span class="cal-day__dots" aria-hidden="true">
                                    <?php if($celda['tiene_ingreso']): ?><i class="dot dot--green"></i><?php endif; ?>
                                    <?php if($celda['tiene_pago']): ?><i class="dot dot--red"></i><?php endif; ?>
                                    <?php if($celda['tiene_vencido'] ?? false): ?><i class="dot dot--amber"></i><?php endif; ?>
                                </span>
                            <?php endif; ?>
                        </a>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="cal-legend">
                <span><i class="dot dot--green"></i> Ingreso</span>
                <span><i class="dot dot--red"></i> Salida</span>
                <span><i class="dot dot--amber"></i> Vencido</span>
            </div>
        </section>

        <section class="cal-agenda dash-card" aria-label="Agenda del día">
            <div class="cal-agenda__head">
                <div>
                    <p class="form-section__eyebrow">Día</p>
                    <h2 class="cal-agenda__title"><?php echo e($etiquetaDia); ?></h2>
                </div>
                <span class="cal-agenda__count"><?php echo e(count($eventosDia)); ?></span>
            </div>

            <div class="cal-agenda__list">
                <?php $__empty_1 = true; $__currentLoopData = $eventosDia; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $iconoEvento = match ($evento['tipo']) {
                            'ingreso' => 'arrow-up',
                            'gasto' => 'arrow-down',
                            'pago', 'cuota', 'limite_tarjeta' => 'banknote',
                            'corte' => 'credit-card',
                            default => 'circle',
                        };
                        $estadoClase = match ($evento['estado']) {
                            'vencido' => 'is-overdue',
                            'proyectado' => 'is-projected',
                            default => 'is-real',
                        };
                    ?>
                    <article class="cal-event <?php echo e($estadoClase); ?>">
                        <div class="cal-event__icon"><?php echo $__env->make('layouts.partials.icon', ['name' => $iconoEvento, 'class' => 'ui-icon ui-icon--sm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                        <div class="cal-event__body">
                            <div class="cal-event__row">
                                <h3><?php echo e($evento['descripcion']); ?></h3>
                                <strong class="<?php echo e($evento['tipo'] === 'ingreso' ? 'text-success' : ''); ?>">
                                    <?php if($evento['monto_centavos'] > 0): ?><?php echo \App\Support\Dinero::formatear($evento['monto_centavos']); ?><?php else: ?> — <?php endif; ?>
                                </strong>
                            </div>
                            <div class="cal-event__meta">
                                <span><?php echo e(ucfirst(str_replace('_', ' ', $evento['tipo']))); ?></span>
                                <span class="cal-event__state"><?php echo e(ucfirst($evento['estado'])); ?></span>
                            </div>
                        </div>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="alert alert-light empty-state mb-0">No hay eventos en este día. Elige otra fecha en la grilla.</div>
                <?php endif; ?>
            </div>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', [
    'title' => 'Calendario financiero',
    'heading' => 'Calendario',
    'subtitle' => 'Mapa del mes y detalle del día seleccionado.',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/angelpenaloza/Documents/GitHub/finanzas/resources/views/calendario/index.blade.php ENDPATH**/ ?>