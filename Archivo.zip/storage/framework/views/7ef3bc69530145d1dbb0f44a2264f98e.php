<?php $__env->startSection('content'); ?>
<?php
    $errPagoPrestamo = $errors->pago_prestamo;
    $prestamoConError = $errPagoPrestamo->any() ? (int) old('prestamo_id') : null;
?>
<?php echo $__env->make('layouts.partials.form-errors', ['bag' => 'pago_prestamo'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="list-block list-block--flush">
<div class="list-block__head">
    <h2>Obligaciones</h2>
    <span><?php echo e($prestamos->count() + $tarjetas->count()); ?></span>
</div>
<div class="card-stack">
<?php $__currentLoopData = $prestamos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deuda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php
    $proxima = $deuda->cuotas->firstWhere('pagada', false);
    $montoCuotaCentavos = $proxima
        ? (int) ($proxima->total_centavos ?: ($proxima->capital_centavos + $proxima->interes_centavos + $proxima->seguro_centavos + $proxima->otros_cargos_centavos))
        : 0;
    $montoCuotaPrefijo = $proxima ? \App\Support\Dinero::centavosAPesos($montoCuotaCentavos) : '';
    $esteForm = $proxima && $prestamoConError === (int) $deuda->id;
?>
<article class="account-card">
    <div class="account-card__main">
        <div class="account-card__icon"><?php echo $__env->make('layouts.partials.icon', ['name' => 'file-invoice', 'class' => 'ui-icon ui-icon--sm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
        <div class="account-card__body">
            <div class="account-card__head">
                <div class="account-card__title">
                    <h2><?php echo e($deuda->nombre); ?></h2>
                    <small><?php echo e($deuda->entidad ?: 'Obligación'); ?> · <?php echo e(str_replace('_', ' ', $deuda->tipo_obligacion)); ?></small>
                </div>
                <strong class="account-card__amount"><?php echo \App\Support\Dinero::formatear($deuda->saldo_actual_centavos); ?></strong>
            </div>
            <div class="debt-meta">
                <span><?php echo e($deuda->cuotas_pagadas); ?> pagadas</span>
                <span><?php echo e($deuda->cuotas_pendientes); ?> pendientes</span>
                <span class="status-pill"><?php echo e(ucfirst($deuda->estado)); ?></span>
            </div>
        </div>
    </div>
    <div class="account-card__footer">
        <?php if($proxima): ?>
        <form method="POST" action="<?php echo e(route('app.deudas.pagos.store')); ?>" class="row g-2 align-items-end" novalidate>
            <?php echo csrf_field(); ?>
            <input type="hidden" name="prestamo_id" value="<?php echo e($deuda->id); ?>">
            <div class="col-md-4">
                <label class="form-label small mb-1">Pagar cuota <?php echo e($proxima->numero); ?></label>
                <input name="monto" data-miles inputmode="decimal" class="form-control <?php if($esteForm): ?> <?php $__errorArgs = ['monto', 'pago_prestamo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <?php endif; ?>" value="<?php echo e($esteForm ? old('monto', $montoCuotaPrefijo) : $montoCuotaPrefijo); ?>" required>
                <?php if($esteForm): ?>
                    <?php echo $__env->make('layouts.partials.field-error', ['name' => 'monto', 'bag' => 'pago_prestamo'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
            </div>
            <div class="col-md-4">
                <label class="form-label small mb-1">Fecha</label>
                <input name="fecha" type="date" value="<?php echo e($esteForm ? old('fecha', now()->toDateString()) : now()->toDateString()); ?>" class="form-control <?php if($esteForm): ?> <?php $__errorArgs = ['fecha', 'pago_prestamo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <?php endif; ?>" required>
                <?php if($esteForm): ?>
                    <?php echo $__env->make('layouts.partials.field-error', ['name' => 'fecha', 'bag' => 'pago_prestamo'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
            </div>
            <div class="col-md-4">
                <button class="card-btn card-btn--primary card-btn--block" type="submit">
                    <?php echo $__env->make('layouts.partials.icon', ['name' => 'money', 'class' => 'ui-icon ui-icon--xs'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    Registrar pago
                </button>
            </div>
        </form>
        <?php endif; ?>
        <details class="<?php echo e($proxima ? 'mt-2' : ''); ?>">
            <summary class="small">Ver cronograma</summary>
            <div class="table-responsive mt-2">
                <table class="table table-sm small mb-0">
                    <thead><tr><th>Cuota</th><th>Fecha</th><th>Capital</th><th>Interés</th><th>Otros</th><th>Total</th><th>Saldo</th><th></th></tr></thead>
                    <tbody>
                    <?php $__currentLoopData = $deuda->cuotas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="<?php echo e($cuota->pagada ? 'text-secondary' : ''); ?>">
                        <td><?php echo e($cuota->numero); ?></td>
                        <td><?php echo e($cuota->fecha_vencimiento->format('d/m/Y')); ?></td>
                        <td><?php echo \App\Support\Dinero::formatear($cuota->capital_centavos); ?></td>
                        <td><?php echo \App\Support\Dinero::formatear($cuota->interes_centavos); ?></td>
                        <td><?php echo \App\Support\Dinero::formatear($cuota->seguro_centavos + $cuota->otros_cargos_centavos); ?></td>
                        <td><?php echo \App\Support\Dinero::formatear($cuota->total_centavos); ?></td>
                        <td><?php echo \App\Support\Dinero::formatear($cuota->saldo_capital_centavos); ?></td>
                        <td><?php echo e($cuota->pagada ? 'Pagada' : 'Pendiente'); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </details>
    </div>
</article>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $tarjetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deuda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<article class="account-card">
    <div class="account-card__main">
        <div class="account-card__icon"><?php echo $__env->make('layouts.partials.icon', ['name' => 'credit-card', 'class' => 'ui-icon ui-icon--sm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
        <div class="account-card__body">
            <div class="account-card__head">
                <div class="account-card__title">
                    <h2><?php echo e($deuda->nombre); ?></h2>
                    <small><?php echo e($deuda->entidad ?: 'Tarjeta de crédito'); ?></small>
                </div>
                <strong class="account-card__amount"><?php echo \App\Support\Dinero::formatear($deuda->saldo_actual_centavos); ?></strong>
            </div>
            <div class="debt-meta">
                <span>Cupo <?php echo \App\Support\Dinero::formatear($deuda->cupo_centavos); ?></span>
                <span><?php echo e($deuda->cuotas_pendientes); ?> pendientes</span>
                <span class="status-pill"><?php echo e(ucfirst($deuda->estado)); ?></span>
            </div>
            <p class="small text-secondary mb-0 mt-2">Gestiona compras y pagos en <a href="<?php echo e(route('app.tarjetas.index')); ?>">Tarjetas</a>.</p>
        </div>
    </div>
</article>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php if($prestamos->isEmpty() && $tarjetas->isEmpty()): ?>
    <div class="alert alert-light empty-state">Aún no tienes obligaciones registradas.</div>
<?php endif; ?>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', [
    'title' => 'Deudas',
    'heading' => 'Mis deudas',
    'subtitle' => 'Todo lo que debes, con claridad.',
    'actionUrl' => route('app.deudas.create'),
    'actionLabel' => 'Nueva deuda',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/angelpenaloza/Documents/GitHub/finanzas/resources/views/deudas/index.blade.php ENDPATH**/ ?>