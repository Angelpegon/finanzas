<?php
    use App\Support\InstitucionFinanciera;

    $name = $name ?? 'institucion';
    $otraName = $otraName ?? $name.'_otra';
    $label = $label ?? 'Institución';
    $required = $required ?? false;
    $bag = $bag ?? null;
    $oldSlug = old($name);
    $oldOtra = old($otraName);
    $current = $current ?? null;
    if ($oldSlug === null && $current) {
        $resolved = InstitucionFinanciera::resolver($current);
        $oldSlug = $resolved ?? 'otra';
        $oldOtra = $resolved ? '' : $current;
    }
    $mostrarOtra = ($oldSlug === 'otra') || ($oldSlug && ! array_key_exists((string) $oldSlug, InstitucionFinanciera::opcionesSelect()));
    if ($mostrarOtra && $oldSlug && $oldSlug !== 'otra' && $oldOtra === null) {
        $oldOtra = InstitucionFinanciera::etiqueta($oldSlug) ?: $oldSlug;
        $oldSlug = 'otra';
    }
?>
<div data-institucion-picker>
    <label class="form-label" for="<?php echo e($name); ?>"><?php echo e($label); ?><?php if (! ($required)): ?> <span class="text-secondary">(opcional)</span><?php endif; ?></label>
    <select
        id="<?php echo e($name); ?>"
        name="<?php echo e($name); ?>"
        class="form-select form-select-lg <?php $__errorArgs = [$name, $bag];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
        data-institucion-select
        <?php if($required): ?> required <?php endif; ?>
    >
        <option value="">Selecciona institución</option>
        <?php $__currentLoopData = InstitucionFinanciera::opcionesSelect(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slug => $texto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($slug); ?>" <?php if((string) $oldSlug === (string) $slug): echo 'selected'; endif; ?>><?php echo e($texto); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php echo $__env->make('layouts.partials.field-error', ['name' => $name, 'bag' => $bag], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="mt-2" data-institucion-otra <?php if(! $mostrarOtra): ?> hidden <?php endif; ?>>
        <label class="form-label" for="<?php echo e($otraName); ?>">Nombre de la institución</label>
        <input
            id="<?php echo e($otraName); ?>"
            name="<?php echo e($otraName); ?>"
            value="<?php echo e($oldOtra); ?>"
            class="form-control form-control-lg <?php $__errorArgs = [$otraName, $bag];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
            placeholder="Banco, billetera o entidad"
            <?php if($mostrarOtra && $required): ?> required <?php endif; ?>
        >
        <?php echo $__env->make('layouts.partials.field-error', ['name' => $otraName, 'bag' => $bag], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<?php /**PATH /Users/angelpenaloza/Documents/GitHub/finanzas/resources/views/layouts/partials/institucion-field.blade.php ENDPATH**/ ?>