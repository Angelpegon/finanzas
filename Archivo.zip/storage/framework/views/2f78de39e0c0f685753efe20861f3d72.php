<div class="offcanvas offcanvas-bottom alerts-sheet" tabindex="-1" id="alerts-sheet" aria-labelledby="alerts-sheet-title">
    <div class="offcanvas-header">
        <h2 id="alerts-sheet-title" class="offcanvas-title h5 mb-0">Alertas</h2>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Cerrar alertas"></button>
    </div>
    <div class="offcanvas-body">
        <?php $__empty_1 = true; $__currentLoopData = ($alertasLista ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alerta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="header-alerts__item header-alerts__item--<?php echo e($alerta['nivel']); ?>">
                <strong><?php echo e($alerta['titulo']); ?></strong>
                <span><?php echo e($alerta['mensaje']); ?></span>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="header-alerts__empty">Sin alertas por ahora.</p>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH /Users/angelpenaloza/Documents/GitHub/finanzas/resources/views/layouts/partials/alerts-sheet.blade.php ENDPATH**/ ?>