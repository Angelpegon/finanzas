
<link rel="stylesheet" href="<?php echo e(asset('assets/css/fonts.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/fontawesome/css/all.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/css/sweetalert2.min.css')); ?>">
<script src="<?php echo e(asset('assets/js/jquery-4.0.0.min.js')); ?>"></script>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
<?php /**PATH /Users/angelpenaloza/Documents/GitHub/finanzas/resources/views/layouts/partials/vendor-head.blade.php ENDPATH**/ ?>