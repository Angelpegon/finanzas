<?php $__env->startSection('content'); ?>
<div class="capture-flow">
    <p class="capture-hint"><strong>Gasto real</strong> mueve el libro hoy. Activa “proyectado” si solo quieres anticiparlo en el plan.</p>
    <?php echo $__env->make('layouts.partials.form-errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <form method="POST" action="<?php echo e(route('app.gastos.store')); ?>" class="dash-card form-panel" novalidate>
        <?php echo csrf_field(); ?>
        <div class="money-hero">
            <label class="form-label" for="monto">Monto en pesos</label>
            <input id="monto" name="monto" type="text" inputmode="decimal" data-miles value="<?php echo e(old('monto')); ?>" class="form-control form-control-lg <?php $__errorArgs = ['monto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="0" autocomplete="off" required>
            <?php echo $__env->make('layouts.partials.field-error', ['name' => 'monto'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <section class="form-section">
            <div class="form-section__head">
                <p class="form-section__eyebrow">Clasificación</p>
                <h2 class="form-section__title">Categoría y cuenta</h2>
            </div>
            <div>
                <label class="form-label" for="fecha">Fecha</label>
                <input id="fecha" name="fecha" type="date" value="<?php echo e(old('fecha', now()->toDateString())); ?>" class="form-control form-control-lg <?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                <?php echo $__env->make('layouts.partials.field-error', ['name' => 'fecha'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div>
                <label class="form-label" for="categoria_id">Categoría</label>
                <select id="categoria_id" name="categoria_id" class="form-select form-select-lg <?php $__errorArgs = ['categoria_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                    <option value="">Selecciona una categoría</option>
                    <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($categoria->id); ?>" <?php if(old('categoria_id') == $categoria->id): echo 'selected'; endif; ?>><?php echo e($categoria->nombre); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php echo $__env->make('layouts.partials.field-error', ['name' => 'categoria_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div>
                <label class="form-label" for="tipo_gasto">Tipo</label>
                <select id="tipo_gasto" name="tipo_gasto" class="form-select form-select-lg <?php $__errorArgs = ['tipo_gasto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                    <?php $__currentLoopData = ['fijo'=>'Fijo','variable'=>'Variable','extraordinario'=>'Extraordinario']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valor => $texto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($valor); ?>" <?php if(old('tipo_gasto', 'variable') === $valor): echo 'selected'; endif; ?>><?php echo e($texto); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php echo $__env->make('layouts.partials.field-error', ['name' => 'tipo_gasto'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div>
                <label class="form-label" for="cuenta_liquida_id">Cuenta de pago</label>
                <select id="cuenta_liquida_id" name="cuenta_liquida_id" class="form-select form-select-lg <?php $__errorArgs = ['cuenta_liquida_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                    <option value="">Selecciona una cuenta</option>
                    <?php $__currentLoopData = $cuentas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuenta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cuenta->id); ?>" <?php if(old('cuenta_liquida_id') == $cuenta->id): echo 'selected'; endif; ?>><?php echo e($cuenta->nombre); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php echo $__env->make('layouts.partials.field-error', ['name' => 'cuenta_liquida_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div>
                <label class="form-label" for="descripcion">Descripción <span class="text-secondary">(opcional)</span></label>
                <input id="descripcion" name="descripcion" value="<?php echo e(old('descripcion')); ?>" class="form-control form-control-lg <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Ej. Mercado del mes">
                <?php echo $__env->make('layouts.partials.field-error', ['name' => 'descripcion'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </section>

        <section class="form-section">
            <div class="form-section__head">
                <p class="form-section__eyebrow">Plan</p>
                <h2 class="form-section__title">¿Se repite o es proyección?</h2>
            </div>
            <div>
                <label class="form-label" for="periodicidad">Periodicidad</label>
                <select id="periodicidad" name="periodicidad" class="form-select form-select-lg <?php $__errorArgs = ['periodicidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                    <?php $__currentLoopData = ['unico'=>'Único','diario'=>'Diario','semanal'=>'Semanal','quincenal'=>'Quincenal','mensual'=>'Mensual','anual'=>'Anual']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valor => $texto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($valor); ?>" <?php if(old('periodicidad', 'unico') === $valor): echo 'selected'; endif; ?>><?php echo e($texto); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php echo $__env->make('layouts.partials.field-error', ['name' => 'periodicidad'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="form-switch-card">
                <div class="form-check form-switch">
                    <input id="proyectado" name="proyectado" value="1" type="checkbox" class="form-check-input" <?php if(old('proyectado')): echo 'checked'; endif; ?>>
                    <label for="proyectado" class="form-check-label">Es un gasto proyectado</label>
                </div>
                <small class="text-secondary">No afecta saldos ni movimientos reales.</small>
            </div>
        </section>

        <div class="form-actions">
            <button class="btn btn-primary btn-lg w-100" type="submit">Guardar gasto</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', [
    'title' => 'Registrar gasto',
    'heading' => '¿En qué gastaste?',
    'subtitle' => 'Un gasto real descuenta tu cuenta; uno proyectado solo ayuda a planear.',
    'backUrl' => route('app.situacion'),
    'backLabel' => 'Volver al resumen',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/angelpenaloza/Documents/GitHub/finanzas/resources/views/gastos/create.blade.php ENDPATH**/ ?>