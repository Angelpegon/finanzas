<?php $__env->startSection('content'); ?>
<div class="capture-flow">
    <p class="capture-hint"><strong>Solo el cupo.</strong> Las compras y pagos se registran después, con asientos en el libro.</p>
    <?php echo $__env->make('layouts.partials.form-errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <form method="POST" action="<?php echo e(route('app.tarjetas.store')); ?>" class="dash-card form-panel" novalidate>
        <?php echo csrf_field(); ?>

        <div class="money-hero">
            <label class="form-label" for="cupo">Cupo total</label>
            <input id="cupo" name="cupo" value="<?php echo e(old('cupo')); ?>" type="text" data-miles inputmode="decimal" class="form-control form-control-lg <?php $__errorArgs = ['cupo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="0" required>
            <?php echo $__env->make('layouts.partials.field-error', ['name' => 'cupo'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <section class="form-section">
            <div class="form-section__head">
                <p class="form-section__eyebrow">Tarjeta</p>
                <h2 class="form-section__title">Banco y nombre</h2>
            </div>
            <div>
                <label class="form-label" for="entidad">Banco o entidad</label>
                <input id="entidad" name="entidad" value="<?php echo e(old('entidad')); ?>" class="form-control form-control-lg <?php $__errorArgs = ['entidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                <?php echo $__env->make('layouts.partials.field-error', ['name' => 'entidad'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div>
                <label class="form-label" for="nombre">Nombre de la tarjeta</label>
                <input id="nombre" name="nombre" value="<?php echo e(old('nombre')); ?>" class="form-control form-control-lg <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Ej. Visa clásica" required>
                <?php echo $__env->make('layouts.partials.field-error', ['name' => 'nombre'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </section>

        <section class="form-section">
            <div class="form-section__head">
                <p class="form-section__eyebrow">Ciclo</p>
                <h2 class="form-section__title">Tasa y fechas clave</h2>
            </div>
            <div>
                <label class="form-label" for="tasa">Tasa mensual (%)</label>
                <input id="tasa" name="tasa" value="<?php echo e(old('tasa', 0)); ?>" type="number" min="0" step="0.01" class="form-control form-control-lg <?php $__errorArgs = ['tasa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                <?php echo $__env->make('layouts.partials.field-error', ['name' => 'tasa'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="row g-3">
                <div class="col-6">
                    <label class="form-label" for="dia_corte">Día de corte</label>
                    <input id="dia_corte" name="dia_corte" value="<?php echo e(old('dia_corte', 15)); ?>" type="number" min="1" max="31" class="form-control form-control-lg <?php $__errorArgs = ['dia_corte'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                    <?php echo $__env->make('layouts.partials.field-error', ['name' => 'dia_corte'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-6">
                    <label class="form-label" for="dia_pago">Día límite de pago</label>
                    <input id="dia_pago" name="dia_pago" value="<?php echo e(old('dia_pago', 30)); ?>" type="number" min="1" max="31" class="form-control form-control-lg <?php $__errorArgs = ['dia_pago'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                    <?php echo $__env->make('layouts.partials.field-error', ['name' => 'dia_pago'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </section>

        <div class="form-actions">
            <button class="btn btn-primary btn-lg w-100" type="submit">Guardar tarjeta</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', [
    'title' => 'Nueva tarjeta',
    'heading' => 'Registra tu tarjeta',
    'subtitle' => 'El cupo y las compras quedarán separados de tus cuentas de efectivo.',
    'backUrl' => route('app.tarjetas.index'),
    'backLabel' => 'Volver a tarjetas',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/angelpenaloza/Documents/GitHub/finanzas/resources/views/tarjetas/create.blade.php ENDPATH**/ ?>