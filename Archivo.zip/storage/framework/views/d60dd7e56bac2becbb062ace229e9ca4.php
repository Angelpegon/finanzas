<!doctype html>
<html lang="es">

<head>
    <?php echo $__env->make('layouts.partials.pwa-meta', ['title' => $title ?? 'Finanzas'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.partials.boot-splash-head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php echo $__env->make('layouts.partials.vendor-head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body class="auth-page">
    <?php echo $__env->make('layouts.partials.boot-splash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.partials.pwa-install', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if(session('status')): ?>
        <script type="application/json" id="flash-status"><?php echo json_encode(session('status'), 15, 512) ?></script>
    <?php endif; ?>
    <main class="auth-shell">
        <section class="auth-stage" aria-label="Finanzas">
            <div class="auth-stage__glow" aria-hidden="true"></div>
            <div class="auth-stage__copy">
                <img class="auth-stage__logo" src="<?php echo e(asset('icons/icon-192.png')); ?>" width="56" height="56" alt="" decoding="async"
                     onerror="this.replaceWith(Object.assign(document.createElement('div'),{className:'brand-mark brand-mark--small',textContent:'$'}))">
                <p class="auth-stage__eyebrow">Finanzas personales</p>
                <h1 class="auth-stage__title">Tu dinero, con claridad.</h1>
                <p class="auth-stage__text">Saldos reales, deudas y metas en un solo lugar. Sin hojas de cálculo ni sorpresas.</p>
                <ul class="auth-stage__points">
                    <li>Libro contable que cuadra</li>
                    <li>Disponible después de compromisos</li>
                    <li>Pensado para usar en el celular</li>
                </ul>
            </div>
        </section>
        <section class="auth-panel">
            <div class="auth-card"><?php echo $__env->yieldContent('content'); ?></div>
        </section>
    </main>
    <?php echo $__env->make('layouts.partials.vendor-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH /Users/angelpenaloza/Documents/GitHub/finanzas/resources/views/layouts/guest.blade.php ENDPATH**/ ?>