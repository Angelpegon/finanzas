<?php $__env->startSection('content'); ?>
<div class="capture-flow">
    <p class="capture-hint"><strong>Desembolso real:</strong> al guardar, el monto entra a tu cuenta y nace el cronograma de cuotas.</p>
    <?php echo $__env->make('layouts.partials.form-errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <form method="POST" action="<?php echo e(route('app.deudas.store')); ?>" class="dash-card form-panel" novalidate>
        <?php echo csrf_field(); ?>

        <div class="money-hero">
            <label class="form-label" for="monto_inicial">Monto inicial</label>
            <input id="monto_inicial" name="monto_inicial" value="<?php echo e(old('monto_inicial')); ?>" type="text" data-miles inputmode="decimal" class="form-control form-control-lg <?php $__errorArgs = ['monto_inicial'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="0" required>
            <?php echo $__env->make('layouts.partials.field-error', ['name' => 'monto_inicial'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <section class="form-section">
            <div class="form-section__head">
                <p class="form-section__eyebrow">Identidad</p>
                <h2 class="form-section__title">Qué es y con quién</h2>
            </div>
            <div>
                <label class="form-label" for="nombre">Nombre</label>
                <input id="nombre" name="nombre" value="<?php echo e(old('nombre')); ?>" class="form-control form-control-lg <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Ej. Crédito de vehículo" required>
                <?php echo $__env->make('layouts.partials.field-error', ['name' => 'nombre'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div>
                <label class="form-label" for="entidad">Entidad</label>
                <input id="entidad" name="entidad" value="<?php echo e(old('entidad')); ?>" class="form-control form-control-lg <?php $__errorArgs = ['entidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Banco, persona o comercio">
                <?php echo $__env->make('layouts.partials.field-error', ['name' => 'entidad'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div>
                <label class="form-label" for="tipo_obligacion">Tipo</label>
                <select id="tipo_obligacion" name="tipo_obligacion" class="form-select form-select-lg <?php $__errorArgs = ['tipo_obligacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                    <?php $__currentLoopData = ['prestamo_bancario'=>'Préstamo bancario','credito'=>'Crédito','tarjeta_credito'=>'Tarjeta de crédito','prestamo_personal'=>'Préstamo personal','compra_financiada'=>'Compra financiada','deuda_informal'=>'Deuda informal','otra_obligacion'=>'Otra obligación']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v=>$t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($v); ?>" <?php if(old('tipo_obligacion') === $v): echo 'selected'; endif; ?>><?php echo e($t); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php echo $__env->make('layouts.partials.field-error', ['name' => 'tipo_obligacion'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </section>

        <section class="form-section">
            <div class="form-section__head">
                <p class="form-section__eyebrow">Condiciones</p>
                <h2 class="form-section__title">Tasa y amortización</h2>
            </div>
            <div class="row g-3">
                <div class="col-7">
                    <label class="form-label" for="tasa_interes">Tasa de interés (%)</label>
                    <input id="tasa_interes" name="tasa_interes" value="<?php echo e(old('tasa_interes', 0)); ?>" type="number" min="0" step="0.01" class="form-control form-control-lg <?php $__errorArgs = ['tasa_interes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                    <?php echo $__env->make('layouts.partials.field-error', ['name' => 'tasa_interes'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-5">
                    <label class="form-label" for="tipo_tasa">Tipo</label>
                    <select id="tipo_tasa" name="tipo_tasa" class="form-select form-select-lg <?php $__errorArgs = ['tipo_tasa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <?php $__currentLoopData = ['ea'=>'EA','mensual'=>'Mensual','nominal'=>'Nominal']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v=>$t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($v); ?>" <?php if(old('tipo_tasa', 'ea') === $v): echo 'selected'; endif; ?>><?php echo e($t); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php echo $__env->make('layouts.partials.field-error', ['name' => 'tipo_tasa'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <div>
                <label class="form-label" for="metodo_amortizacion">Método de amortización</label>
                <select id="metodo_amortizacion" name="metodo_amortizacion" class="form-select form-select-lg <?php $__errorArgs = ['metodo_amortizacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                    <?php $__currentLoopData = ['frances'=>'Francés · cuota estable','lineal'=>'Lineal · capital estable','solo_interes'=>'Solo interés · capital al final']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v=>$t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($v); ?>" <?php if(old('metodo_amortizacion', 'frances') === $v): echo 'selected'; endif; ?>><?php echo e($t); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php echo $__env->make('layouts.partials.field-error', ['name' => 'metodo_amortizacion'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="row g-3">
                <div class="col-6">
                    <label class="form-label" for="seguro">Seguro por cuota</label>
                    <input id="seguro" name="seguro" value="<?php echo e(old('seguro', 0)); ?>" type="text" data-miles inputmode="decimal" class="form-control form-control-lg <?php $__errorArgs = ['seguro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <?php echo $__env->make('layouts.partials.field-error', ['name' => 'seguro'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-6">
                    <label class="form-label" for="otros_cargos">Otros cargos</label>
                    <input id="otros_cargos" name="otros_cargos" value="<?php echo e(old('otros_cargos', 0)); ?>" type="text" data-miles inputmode="decimal" class="form-control form-control-lg <?php $__errorArgs = ['otros_cargos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <?php echo $__env->make('layouts.partials.field-error', ['name' => 'otros_cargos'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </section>

        <section class="form-section">
            <div class="form-section__head">
                <p class="form-section__eyebrow">Calendario</p>
                <h2 class="form-section__title">Plazo y desembolso</h2>
            </div>
            <div class="row g-3">
                <div class="col-6">
                    <label class="form-label" for="fecha_inicio">Fecha inicio</label>
                    <input id="fecha_inicio" name="fecha_inicio" type="date" value="<?php echo e(old('fecha_inicio', now()->toDateString())); ?>" class="form-control form-control-lg <?php $__errorArgs = ['fecha_inicio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                    <?php echo $__env->make('layouts.partials.field-error', ['name' => 'fecha_inicio'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-6">
                    <label class="form-label" for="fecha_vencimiento">Vencimiento</label>
                    <input id="fecha_vencimiento" name="fecha_vencimiento" type="date" value="<?php echo e(old('fecha_vencimiento')); ?>" class="form-control form-control-lg <?php $__errorArgs = ['fecha_vencimiento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <?php echo $__env->make('layouts.partials.field-error', ['name' => 'fecha_vencimiento'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <div class="row g-3">
                <div class="col-7">
                    <label class="form-label" for="periodicidad">Periodicidad</label>
                    <select id="periodicidad" name="periodicidad" class="form-select form-select-lg <?php $__errorArgs = ['periodicidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <?php $__currentLoopData = ['mensual'=>'Mensual','quincenal'=>'Quincenal','semanal'=>'Semanal','anual'=>'Anual']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v=>$t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($v); ?>" <?php if(old('periodicidad', 'mensual') === $v): echo 'selected'; endif; ?>><?php echo e($t); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php echo $__env->make('layouts.partials.field-error', ['name' => 'periodicidad'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-5">
                    <label class="form-label" for="numero_cuotas">Cuotas</label>
                    <input id="numero_cuotas" name="numero_cuotas" value="<?php echo e(old('numero_cuotas', 12)); ?>" type="number" min="1" class="form-control form-control-lg <?php $__errorArgs = ['numero_cuotas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                    <?php echo $__env->make('layouts.partials.field-error', ['name' => 'numero_cuotas'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <div>
                <label class="form-label" for="cuenta_liquida_id">Cuenta para recibir el desembolso</label>
                <select id="cuenta_liquida_id" name="cuenta_liquida_id" class="form-select form-select-lg <?php $__errorArgs = ['cuenta_liquida_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                    <option value="">Selecciona una cuenta</option>
                    <?php $__currentLoopData = $cuentas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuenta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cuenta->id); ?>" <?php if(old('cuenta_liquida_id') == $cuenta->id): echo 'selected'; endif; ?>><?php echo e($cuenta->nombre); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php echo $__env->make('layouts.partials.field-error', ['name' => 'cuenta_liquida_id'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </section>

        <div class="form-actions">
            <button class="btn btn-primary btn-lg w-100" type="submit">Guardar obligación</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', [
    'title' => 'Nueva obligación',
    'heading' => 'Registra lo que debes',
    'subtitle' => 'El saldo y las cuotas se calcularán desde el calendario.',
    'backUrl' => route('app.deudas.index'),
    'backLabel' => 'Volver a deudas',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/angelpenaloza/Documents/GitHub/finanzas/resources/views/deudas/create.blade.php ENDPATH**/ ?>