<?php $__env->startSection('content'); ?>
<?php
    $errCompra = $errors->compra;
    $errPagoTarjeta = $errors->pago_tarjeta;
    $oldCompra = $errCompra->any();
?>

<div class="capture-flow capture-flow--wide">
    <?php echo $__env->make('layouts.partials.form-errors', ['bag' => 'pago_tarjeta'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="list-block list-block--flush">
        <div class="list-block__head">
            <h2>Tarjetas activas</h2>
            <span><?php echo e($tarjetas->count()); ?></span>
        </div>
        <div class="card-stack">
        <?php $__empty_1 = true; $__currentLoopData = $tarjetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarjeta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <article class="account-card">
            <div class="account-card__main">
                <div class="account-card__icon"><?php echo $__env->make('layouts.partials.icon', ['name' => 'credit-card', 'class' => 'ui-icon ui-icon--sm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                <div class="account-card__body">
                    <div class="account-card__head">
                        <div class="account-card__title">
                            <h2><?php echo e($tarjeta->nombre); ?></h2>
                            <small><?php echo e($tarjeta->entidad ?: 'Tarjeta de crédito'); ?></small>
                        </div>
                        <strong class="account-card__amount"><?php echo \App\Support\Dinero::formatear($tarjeta->saldo_actual_centavos); ?></strong>
                    </div>
                    <div class="debt-meta">
                        <span>Disponible <?php echo \App\Support\Dinero::formatear($tarjeta->cupo_disponible_centavos); ?></span>
                        <span>Cupo <?php echo \App\Support\Dinero::formatear($tarjeta->cupo_centavos); ?></span>
                    </div>
                    <div class="small text-secondary mt-2">Pago mínimo: <strong><?php echo \App\Support\Dinero::formatear($tarjeta->pago_minimo_centavos); ?></strong> · Pago total: <strong><?php echo \App\Support\Dinero::formatear($tarjeta->pago_total_centavos); ?></strong></div>
                </div>
            </div>
            <div class="account-card__footer">
                <details <?php if($errPagoTarjeta->any() && (int) old('tarjeta_credito_id') === (int) $tarjeta->id): ?> open <?php endif; ?>>
                    <summary class="small">Ver compras y cuotas</summary>
                    <div class="table-responsive mt-2">
                        <table class="table table-sm small mb-0">
                            <thead><tr><th>Compra</th><th>Fecha</th><th>Monto</th><th>Cuotas</th></tr></thead>
                            <tbody>
                            <?php $__currentLoopData = $tarjeta->compras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $compra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($compra->descripcion); ?></td>
                                    <td><?php echo e($compra->fecha->format('d/m/Y')); ?></td>
                                    <td><?php echo \App\Support\Dinero::formatear($compra->monto_centavos); ?></td>
                                    <td><?php echo e($compra->cuotas); ?> (<?php echo e($compra->cuotasProgramadas->where('pagada', false)->count()); ?> pendientes)</td>
                                </tr>
                                <?php $__currentLoopData = $compra->cuotasProgramadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-secondary">
                                    <td>↳ Cuota <?php echo e($cuota->numero); ?></td>
                                    <td><?php echo e($cuota->fecha_vencimiento->format('d/m/Y')); ?></td>
                                    <td><?php echo \App\Support\Dinero::formatear($cuota->capital_centavos + $cuota->interes_centavos); ?></td>
                                    <td>
                                        <?php echo e($cuota->pagada ? 'Pagada' : 'Pendiente'); ?>

                                        <?php if (! ($cuota->pagada)): ?>
                                        <?php $estePagoCuota = $errPagoTarjeta->any() && (int) old('cuota_tarjeta_id') === (int) $cuota->id; ?>
                                        <form method="POST" action="<?php echo e(route('app.tarjetas.pagos.store')); ?>" class="d-inline-flex flex-wrap align-items-center gap-1 ms-2" novalidate>
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="tarjeta_credito_id" value="<?php echo e($tarjeta->id); ?>">
                                            <input type="hidden" name="cuota_tarjeta_id" value="<?php echo e($cuota->id); ?>">
                                            <input type="hidden" name="fecha" value="<?php echo e(now()->toDateString()); ?>">
                                            <select name="cuenta_liquida_id" class="form-select form-select-sm d-inline-block w-auto <?php if($estePagoCuota): ?> <?php $__errorArgs = ['cuenta_liquida_id', 'pago_tarjeta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <?php endif; ?>" required>
                                                <option value="">Cuenta</option>
                                                <?php $__currentLoopData = $cuentas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuenta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($cuenta->id); ?>" <?php if($estePagoCuota && old('cuenta_liquida_id') == $cuenta->id): echo 'selected'; endif; ?>><?php echo e($cuenta->nombre); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <button class="card-btn card-btn--primary" type="submit">
                                                <?php echo $__env->make('layouts.partials.icon', ['name' => 'money', 'class' => 'ui-icon ui-icon--xs'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                Pagar
                                            </button>
                                            <?php if($estePagoCuota): ?>
                                                <?php echo $__env->make('layouts.partials.field-error', ['name' => 'cuenta_liquida_id', 'bag' => 'pago_tarjeta'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                            <?php endif; ?>
                                        </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </details>
            </div>
        </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="alert alert-light empty-state">Aún no tienes tarjetas registradas. <a href="<?php echo e(route('app.tarjetas.create')); ?>">Crear una</a>.</div>
        <?php endif; ?>
        </div>
    </div>

    <?php if($tarjetas->isNotEmpty()): ?>
    <form method="POST" action="<?php echo e(route('app.tarjetas.compras.store')); ?>" class="dash-card form-panel" novalidate>
        <?php echo csrf_field(); ?>
        <div class="form-section__head">
            <p class="form-section__eyebrow">Compra</p>
            <h2 class="form-section__title">Registrar compra financiada</h2>
        </div>
        <?php echo $__env->make('layouts.partials.form-errors', ['bag' => 'compra'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="money-hero">
            <label class="form-label" for="monto_compra">Monto</label>
            <input id="monto_compra" name="monto" data-miles inputmode="decimal" value="<?php echo e($oldCompra ? old('monto') : ''); ?>" class="form-control form-control-lg <?php $__errorArgs = ['monto', 'compra'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="0" required>
            <?php echo $__env->make('layouts.partials.field-error', ['name' => 'monto', 'bag' => 'compra'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <section class="form-section">
            <div>
                <label class="form-label" for="tarjeta_credito_id">Tarjeta</label>
                <select id="tarjeta_credito_id" name="tarjeta_credito_id" class="form-select form-select-lg <?php $__errorArgs = ['tarjeta_credito_id', 'compra'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                    <option value="">Selecciona tarjeta</option>
                    <?php $__currentLoopData = $tarjetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tarjeta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($tarjeta->id); ?>" <?php if($oldCompra && old('tarjeta_credito_id') == $tarjeta->id): echo 'selected'; endif; ?>><?php echo e($tarjeta->nombre); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php echo $__env->make('layouts.partials.field-error', ['name' => 'tarjeta_credito_id', 'bag' => 'compra'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div>
                <label class="form-label" for="descripcion_compra">Descripción</label>
                <input id="descripcion_compra" name="descripcion" value="<?php echo e($oldCompra ? old('descripcion') : ''); ?>" class="form-control form-control-lg <?php $__errorArgs = ['descripcion', 'compra'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Qué compraste" required>
                <?php echo $__env->make('layouts.partials.field-error', ['name' => 'descripcion', 'bag' => 'compra'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div class="row g-3">
                <div class="col-6">
                    <label class="form-label" for="fecha_compra">Fecha</label>
                    <input id="fecha_compra" name="fecha" type="date" value="<?php echo e($oldCompra ? old('fecha', now()->toDateString()) : now()->toDateString()); ?>" class="form-control form-control-lg <?php $__errorArgs = ['fecha', 'compra'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                    <?php echo $__env->make('layouts.partials.field-error', ['name' => 'fecha', 'bag' => 'compra'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-6">
                    <label class="form-label" for="categoria_compra">Categoría</label>
                    <select id="categoria_compra" name="categoria_id" class="form-select form-select-lg <?php $__errorArgs = ['categoria_id', 'compra'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <option value="">Categoría</option>
                        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($categoria->id); ?>" <?php if($oldCompra && old('categoria_id') == $categoria->id): echo 'selected'; endif; ?>><?php echo e($categoria->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php echo $__env->make('layouts.partials.field-error', ['name' => 'categoria_id', 'bag' => 'compra'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <div class="row g-3">
                <div class="col-6">
                    <label class="form-label" for="cuotas">Cuotas</label>
                    <input id="cuotas" name="cuotas" type="number" min="1" max="60" value="<?php echo e($oldCompra ? old('cuotas', 1) : 1); ?>" class="form-control form-control-lg <?php $__errorArgs = ['cuotas', 'compra'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                    <?php echo $__env->make('layouts.partials.field-error', ['name' => 'cuotas', 'bag' => 'compra'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-6">
                    <label class="form-label" for="interes">Interés mensual %</label>
                    <input id="interes" name="interes" type="number" min="0" step="0.01" value="<?php echo e($oldCompra ? old('interes', 0) : 0); ?>" class="form-control form-control-lg <?php $__errorArgs = ['interes', 'compra'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <?php echo $__env->make('layouts.partials.field-error', ['name' => 'interes', 'bag' => 'compra'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </section>

        <div class="form-actions">
            <button class="btn btn-primary btn-lg w-100" type="submit">Guardar compra financiada</button>
        </div>
    </form>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', [
    'title' => 'Tarjetas',
    'heading' => 'Mis tarjetas',
    'subtitle' => 'Compra, financia y paga con trazabilidad.',
    'actionUrl' => route('app.tarjetas.create'),
    'actionLabel' => 'Nueva tarjeta',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/angelpenaloza/Documents/GitHub/finanzas/resources/views/tarjetas/index.blade.php ENDPATH**/ ?>