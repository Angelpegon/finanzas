<?php
    $inicial = strtoupper(substr(auth()->user()->nombre, 0, 1));
?>
<div class="dropdown user-menu" data-user-menu>
    <button type="button" class="user-menu__trigger" data-bs-toggle="dropdown" data-bs-auto-close="outside" aria-expanded="false" aria-haspopup="true">
        <span class="avatar avatar--small"><?php echo e($inicial); ?></span>
        <span class="user-menu__label">Hola, <?php echo e(auth()->user()->nombre); ?></span>
        <?php echo $__env->make('layouts.partials.icon', ['name' => 'chevron-down', 'class' => 'ui-icon ui-icon--sm user-menu__chevron'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </button>
    <div class="dropdown-menu dropdown-menu-end user-menu__panel">
        <form method="POST" action="<?php echo e(route('auth.logout')); ?>" data-swal-confirm data-swal-title="¿Deseas cerrar tu sesión?" data-swal-icon="question" data-swal-confirm-text="Cerrar sesión">
            <?php echo csrf_field(); ?>
            <button class="user-menu__item dropdown-item" type="submit">
                <?php echo $__env->make('layouts.partials.icon', ['name' => 'log-out', 'class' => 'ui-icon ui-icon--sm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <span>Cerrar sesión</span>
            </button>
        </form>
    </div>
</div>
<?php /**PATH /Users/angelpenaloza/Documents/GitHub/finanzas/resources/views/layouts/partials/user-menu.blade.php ENDPATH**/ ?>