<?php $__env->startSection('content'); ?>
<div class="d-flex gap-2 mb-4">
    <?php $__currentLoopData = [3, 6, 12]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opcion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a class="btn <?php echo e($cantidadMeses === $opcion ? 'btn-primary' : 'btn-outline-primary'); ?> rounded-4" href="<?php echo e(route('app.proyecciones', ['meses' => $opcion])); ?>"><?php echo e($opcion); ?> meses</a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="card-stack">
    <?php $__currentLoopData = $meses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <article class="dash-card">
            <div class="dash-card__head">
                <h2><?php echo e($mes['etiqueta']); ?></h2>
                <span class="soft-badge">PROYECTADO</span>
            </div>
            <div class="projection-row"><span>Ingresos</span><strong class="text-success"><?php echo \App\Support\Dinero::formatear($mes['ingresos_centavos']); ?></strong></div>
            <div class="projection-row"><span>Gastos recurrentes</span><strong class="text-danger"><?php echo \App\Support\Dinero::formatear($mes['gastos_centavos']); ?></strong></div>
            <div class="projection-row"><span>Deudas programadas</span><strong class="text-warning"><?php echo \App\Support\Dinero::formatear($mes['deudas_centavos']); ?></strong></div>
            <div class="projection-row"><span>Pagos programados</span><strong><?php echo \App\Support\Dinero::formatear($mes['pagos_centavos']); ?></strong></div>
            <div class="projection-row projection-total"><span>Disponible proyectado</span><strong class="<?php echo e($mes['disponible_centavos'] >= 0 ? 'text-success' : 'text-danger'); ?>"><?php echo \App\Support\Dinero::formatear($mes['disponible_centavos']); ?></strong></div>
        </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<p class="small text-secondary mt-4 mb-0">Las deudas corresponden a cuotas pendientes de préstamos y tarjetas. Los pagos de deuda no se vuelven a restar en esta vista para evitar contabilizar dos veces la misma salida.</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', [
    'title' => 'Proyecciones',
    'heading' => 'Proyecciones',
    'subtitle' => 'Una estimación de lo que puede ocurrir. No modifica ni reemplaza tus movimientos reales.',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/angelpenaloza/Documents/GitHub/finanzas/resources/views/proyecciones/index.blade.php ENDPATH**/ ?>