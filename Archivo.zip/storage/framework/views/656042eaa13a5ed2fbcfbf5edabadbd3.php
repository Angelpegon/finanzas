<?php $__env->startSection('content'); ?>
<div class="capture-flow">
    <p class="capture-hint">El <strong>saldo inicial</strong> genera una apertura en el libro. Después solo cambia con movimientos reales.</p>
    <?php echo $__env->make('layouts.partials.form-errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <form method="POST" action="<?php echo e(route('app.cuentas.store')); ?>" class="dash-card form-panel" novalidate>
        <?php echo csrf_field(); ?>
        <section class="form-section">
            <div class="form-section__head">
                <p class="form-section__eyebrow">Identidad</p>
                <h2 class="form-section__title">Nombre y tipo</h2>
            </div>
            <div>
                <label class="form-label" for="nombre">Nombre</label>
                <input id="nombre" name="nombre" value="<?php echo e(old('nombre')); ?>" class="form-control form-control-lg <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Ej. Cuenta nómina" required>
                <?php echo $__env->make('layouts.partials.field-error', ['name' => 'nombre'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div>
                <label class="form-label" for="tipo">Tipo</label>
                <select id="tipo" name="tipo" class="form-select form-select-lg <?php $__errorArgs = ['tipo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                    <option value="">Selecciona un tipo</option>
                    <?php $__currentLoopData = ['bancaria'=>'Cuenta bancaria','ahorros'=>'Cuenta de ahorros','corriente'=>'Cuenta corriente','efectivo'=>'Efectivo','billetera'=>'Billetera digital','otra'=>'Otra cuenta']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $valor => $texto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($valor); ?>" <?php if(old('tipo') === $valor): echo 'selected'; endif; ?>><?php echo e($texto); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php echo $__env->make('layouts.partials.field-error', ['name' => 'tipo'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div>
                <label class="form-label" for="institucion">Institución <span class="text-secondary">(opcional)</span></label>
                <input id="institucion" name="institucion" value="<?php echo e(old('institucion')); ?>" class="form-control form-control-lg <?php $__errorArgs = ['institucion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Banco o billetera">
                <?php echo $__env->make('layouts.partials.field-error', ['name' => 'institucion'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            <div>
                <label class="form-label" for="numero_cuenta_enmascarado">Número enmascarado <span class="text-secondary">(opcional)</span></label>
                <input id="numero_cuenta_enmascarado" name="numero_cuenta_enmascarado" value="<?php echo e(old('numero_cuenta_enmascarado')); ?>" class="form-control form-control-lg <?php $__errorArgs = ['numero_cuenta_enmascarado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="**** 1234">
                <?php echo $__env->make('layouts.partials.field-error', ['name' => 'numero_cuenta_enmascarado'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </section>

        <div class="money-hero">
            <label class="form-label" for="saldo_inicial">Saldo inicial en pesos</label>
            <input id="saldo_inicial" name="saldo_inicial" value="<?php echo e(old('saldo_inicial', '0')); ?>" type="text" inputmode="decimal" data-miles class="form-control form-control-lg <?php $__errorArgs = ['saldo_inicial'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="0" autocomplete="off" required>
            <small class="text-secondary">No se edita el saldo a mano después de crearla.</small>
            <?php echo $__env->make('layouts.partials.field-error', ['name' => 'saldo_inicial'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>

        <div class="form-actions">
            <button class="btn btn-primary btn-lg w-100" type="submit">Guardar cuenta</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', [
    'title' => 'Agregar cuenta',
    'heading' => '¿Dónde guardas tu dinero?',
    'subtitle' => 'Registra una cuenta para tener una vista completa.',
    'backUrl' => route('app.cuentas.index'),
    'backLabel' => 'Volver a cuentas',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/angelpenaloza/Documents/GitHub/finanzas/resources/views/cuentas/create.blade.php ENDPATH**/ ?>