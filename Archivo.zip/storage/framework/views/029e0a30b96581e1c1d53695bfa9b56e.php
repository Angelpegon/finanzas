<!doctype html>
<html lang="es">

<head>
    <?php echo $__env->make('layouts.partials.pwa-meta', ['title' => $title ?? 'Finanzas'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('layouts.partials.boot-splash-head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <?php echo $__env->make('layouts.partials.vendor-head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body class="app-shell <?php echo e(request()->routeIs('app.situacion') ? 'app-shell--dashboard' : ''); ?>">
    <?php echo $__env->make('layouts.partials.boot-splash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php
        $esDashboard = request()->routeIs('app.situacion');
    ?>
    <?php if(auth()->guard()->check()): ?>
        <?php
            $navTablet = [
                ['ruta' => 'app.situacion', 'patron' => 'app.situacion', 'etiqueta' => 'Inicio'],
                ['ruta' => 'app.cuentas.index', 'patron' => 'app.cuentas.*', 'etiqueta' => 'Cuentas'],
                ['ruta' => 'app.ingresos.create', 'patron' => 'app.ingresos.*', 'etiqueta' => 'Ingresos'],
                ['ruta' => 'app.gastos.create', 'patron' => 'app.gastos.*', 'etiqueta' => 'Gastos'],
                ['ruta' => 'app.pagos.index', 'patron' => 'app.pagos.*', 'etiqueta' => 'Movimientos'],
                ['ruta' => 'app.deudas.index', 'patron' => 'app.deudas.*', 'etiqueta' => 'Deudas'],
                ['ruta' => 'app.tarjetas.index', 'patron' => 'app.tarjetas.*', 'etiqueta' => 'Tarjetas'],
                ['ruta' => 'app.presupuestos.index', 'patron' => 'app.presupuestos.*', 'etiqueta' => 'Presupuesto'],
                ['ruta' => 'app.metas.index', 'patron' => 'app.metas.*', 'etiqueta' => 'Metas'],
                ['ruta' => 'app.calendario', 'patron' => 'app.calendario', 'etiqueta' => 'Calendario'],
                ['ruta' => 'app.proyecciones', 'patron' => 'app.proyecciones', 'etiqueta' => 'Proyecciones'],
            ];
            $masActivo = request()->routeIs(
                'app.cuentas.*',
                'app.presupuestos.*',
                'app.calendario',
                'app.deudas.*',
                'app.tarjetas.*',
                'app.proyecciones',
            );
            $capturaActiva = request()->routeIs('app.ingresos.*', 'app.gastos.*');
            $alertasLista = $alertas ?? [];
            $alertasCount = count($alertasLista);
        ?>
        <aside class="desktop-sidebar">
            <a class="sidebar-brand" href="<?php echo e(route('app.situacion')); ?>">
                <span class="brand-mark brand-mark--small">$</span>
                <span><strong>Finanzas</strong><small>Personales</small></span>
            </a>
            <nav class="sidebar-nav">
                <a class="<?php echo e(request()->routeIs('app.situacion') ? 'active' : ''); ?>" href="<?php echo e(route('app.situacion')); ?>">
                    <?php echo $__env->make('layouts.partials.icon', ['name' => 'chart', 'class' => 'ui-icon ui-icon--sm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <span>Dashboard</span></a>
                <p>Finanzas</p>
                <a class="<?php echo e(request()->routeIs('app.cuentas.*') ? 'active' : ''); ?>"
                    href="<?php echo e(route('app.cuentas.index')); ?>">
                    <?php echo $__env->make('layouts.partials.icon', ['name' => 'wallet', 'class' => 'ui-icon ui-icon--sm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <span>Cuentas</span></a>
                <a class="<?php echo e(request()->routeIs('app.ingresos.*') ? 'active' : ''); ?>"
                    href="<?php echo e(route('app.ingresos.create')); ?>">
                    <?php echo $__env->make('layouts.partials.icon', ['name' => 'arrow-up', 'class' => 'ui-icon ui-icon--sm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <span>Ingresos</span></a>
                <a class="<?php echo e(request()->routeIs('app.gastos.*') ? 'active' : ''); ?>"
                    href="<?php echo e(route('app.gastos.create')); ?>">
                    <?php echo $__env->make('layouts.partials.icon', ['name' => 'arrow-down', 'class' => 'ui-icon ui-icon--sm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <span>Gastos</span></a>
                <a class="<?php echo e(request()->routeIs('app.pagos.*') ? 'active' : ''); ?>" href="<?php echo e(route('app.pagos.index')); ?>">
                    <?php echo $__env->make('layouts.partials.icon', ['name' => 'exchange', 'class' => 'ui-icon ui-icon--sm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <span>Transferencias</span></a>
                <p>Deudas</p>
                <a class="<?php echo e(request()->routeIs('app.deudas.*') ? 'active' : ''); ?>"
                    href="<?php echo e(route('app.deudas.index')); ?>">
                    <?php echo $__env->make('layouts.partials.icon', ['name' => 'file-invoice', 'class' => 'ui-icon ui-icon--sm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <span>Créditos y deudas</span></a>
                <a class="<?php echo e(request()->routeIs('app.tarjetas.*') ? 'active' : ''); ?>"
                    href="<?php echo e(route('app.tarjetas.index')); ?>">
                    <?php echo $__env->make('layouts.partials.icon', ['name' => 'credit-card', 'class' => 'ui-icon ui-icon--sm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <span>Tarjetas</span></a>
                <p>Planificación</p>
                <a class="<?php echo e(request()->routeIs('app.presupuestos.*') ? 'active' : ''); ?>"
                    href="<?php echo e(route('app.presupuestos.index')); ?>">
                    <?php echo $__env->make('layouts.partials.icon', ['name' => 'percent', 'class' => 'ui-icon ui-icon--sm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <span>Presupuesto</span></a>
                <a class="<?php echo e(request()->routeIs('app.metas.*') ? 'active' : ''); ?>" href="<?php echo e(route('app.metas.index')); ?>">
                    <?php echo $__env->make('layouts.partials.icon', ['name' => 'piggy-bank', 'class' => 'ui-icon ui-icon--sm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <span>Metas</span></a>
                <a class="<?php echo e(request()->routeIs('app.calendario') ? 'active' : ''); ?>"
                    href="<?php echo e(route('app.calendario')); ?>">
                    <?php echo $__env->make('layouts.partials.icon', ['name' => 'calendar', 'class' => 'ui-icon ui-icon--sm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <span>Calendario</span></a>
                <p>Análisis</p>
                <a class="<?php echo e(request()->routeIs('app.proyecciones') ? 'active' : ''); ?>"
                    href="<?php echo e(route('app.proyecciones')); ?>">
                    <?php echo $__env->make('layouts.partials.icon', ['name' => 'chart-line', 'class' => 'ui-icon ui-icon--sm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <span>Proyecciones</span></a>
            </nav>
            <div class="sidebar-summary">
                <small>Disponible</small>
                <strong><?php echo \App\Support\Dinero::formatear($situacion['dinero_disponible_real_centavos'] ?? 0); ?></strong>
                <span>Después de compromisos</span>
            </div>
        </aside>
    <?php endif; ?>
    <header class="app-header d-flex justify-content-between align-items-center gap-3">
        <div class="app-header__lead min-w-0 flex-grow-1">
            <?php if(!empty($backUrl)): ?>
                <a href="<?php echo e($backUrl); ?>" class="back-link">
                    <?php echo $__env->make('layouts.partials.icon', ['name' => 'chevron-left', 'class' => 'ui-icon ui-icon--xs'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php echo e($backLabel ?? 'Volver'); ?>

                </a>
            <?php endif; ?>
            <div class="app-header__titles">
                <h1><?php echo e($heading ?? $title ?? 'Finanzas'); ?></h1>
                <?php if(!empty($subtitle)): ?>
                    <p><?php echo e($subtitle); ?></p>
                <?php endif; ?>
            </div>
        </div>
        <div class="app-header__utils d-flex align-items-center flex-shrink-0 gap-2">
            <?php echo $__env->yieldContent('header-utils'); ?>
            <?php if(!empty($actionUrl)): ?>
                <a class="add-button" href="<?php echo e($actionUrl); ?>" aria-label="<?php echo e($actionLabel ?? 'Nuevo'); ?>">
                    <?php echo $__env->make('layouts.partials.icon', ['name' => 'plus', 'class' => 'ui-icon'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </a>
            <?php endif; ?>
            <?php if(auth()->guard()->check()): ?>
                <?php echo $__env->make('layouts.partials.alerts-bell', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('layouts.partials.user-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>
        </div>
    </header>
    <?php if(auth()->guard()->check()): ?>
        <nav class="tablet-nav" aria-label="Navegación tablet">
            <?php $__currentLoopData = $navTablet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="<?php echo e(request()->routeIs($item['patron']) ? 'active' : ''); ?>"
                    href="<?php echo e(route($item['ruta'])); ?>"><?php echo e($item['etiqueta']); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </nav>
    <?php endif; ?>
    <?php echo $__env->make('layouts.partials.pwa-install', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if(session('status')): ?>
        <script type="application/json" id="flash-status"><?php echo json_encode(session('status'), 15, 512) ?></script>
    <?php endif; ?>
    <main class="app-content <?php echo e(!empty($esDashboard) ? 'app-content--dashboard' : ''); ?>">
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <?php if(auth()->guard()->check()): ?>
        <nav class="bottom-nav" aria-label="Navegación móvil">
            <a class="<?php echo e(request()->routeIs('app.situacion') ? 'active' : ''); ?>" href="<?php echo e(route('app.situacion')); ?>">
                <span class="nav-icon"><?php echo $__env->make('layouts.partials.icon', ['name' => 'house', 'class' => 'ui-icon'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></span>
                <span>Dashboard</span>
            </a>
            <a class="<?php echo e(request()->routeIs('app.pagos.*') ? 'active' : ''); ?>" href="<?php echo e(route('app.pagos.index')); ?>">
                <span class="nav-icon"><?php echo $__env->make('layouts.partials.icon', ['name' => 'list', 'class' => 'ui-icon'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></span>
                <span>Movimientos</span>
            </a>
            <button type="button" class="bottom-nav__fab <?php echo e($capturaActiva ? 'is-open' : ''); ?>" data-bs-toggle="offcanvas"
                data-bs-target="#capture-sheet" aria-controls="capture-sheet" aria-label="Registrar ingreso o gasto">
                <?php echo $__env->make('layouts.partials.icon', ['name' => 'plus', 'class' => 'ui-icon'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </button>
            <a class="<?php echo e(request()->routeIs('app.metas.*') ? 'active' : ''); ?>" href="<?php echo e(route('app.metas.index')); ?>">
                <span class="nav-icon"><?php echo $__env->make('layouts.partials.icon', ['name' => 'bullseye', 'class' => 'ui-icon'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></span>
                <span>Metas</span>
            </a>
            <button type="button" class="<?php echo e($masActivo ? 'active' : ''); ?>" data-bs-toggle="offcanvas"
                data-bs-target="#more-sheet" aria-controls="more-sheet" aria-label="Más opciones">
                <span class="nav-icon"><?php echo $__env->make('layouts.partials.icon', ['name' => 'grip', 'class' => 'ui-icon'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></span>
                <span>Más</span>
            </button>
        </nav>
        <?php echo $__env->make('layouts.partials.alerts-sheet', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="offcanvas offcanvas-bottom more-sheet capture-sheet" tabindex="-1" id="capture-sheet" aria-labelledby="capture-sheet-title">
            <div class="offcanvas-header">
                <h2 id="capture-sheet-title" class="offcanvas-title h5 mb-0">Registrar</h2>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Cerrar menú"></button>
            </div>
            <div class="offcanvas-body">
                <a href="<?php echo e(route('app.ingresos.create')); ?>">
                    <?php echo $__env->make('layouts.partials.icon', ['name' => 'arrow-up', 'class' => 'ui-icon'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    Registrar ingreso
                </a>
                <a href="<?php echo e(route('app.gastos.create')); ?>">
                    <?php echo $__env->make('layouts.partials.icon', ['name' => 'arrow-down', 'class' => 'ui-icon'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    Registrar gasto
                </a>
                <a href="<?php echo e(route('app.pagos.index')); ?>">
                    <?php echo $__env->make('layouts.partials.icon', ['name' => 'exchange', 'class' => 'ui-icon'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    Transferencia o pago
                </a>
            </div>
        </div>
        <div class="offcanvas offcanvas-bottom more-sheet" tabindex="-1" id="more-sheet" aria-labelledby="more-sheet-title">
            <div class="offcanvas-header">
                <h2 id="more-sheet-title" class="offcanvas-title h5 mb-0">Más opciones</h2>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" aria-label="Cerrar menú"></button>
            </div>
            <div class="offcanvas-body">
                <p class="eyebrow mb-2">Tesorería</p>
                <a href="<?php echo e(route('app.cuentas.index')); ?>">Cuentas</a>
                <a href="<?php echo e(route('app.pagos.index')); ?>">Transferencias y pagos</a>
                <p class="eyebrow mb-2 mt-3">Deudas</p>
                <a href="<?php echo e(route('app.deudas.index')); ?>">Créditos y deudas</a>
                <a href="<?php echo e(route('app.tarjetas.index')); ?>">Tarjetas</a>
                <p class="eyebrow mb-2 mt-3">Planificación</p>
                <a href="<?php echo e(route('app.presupuestos.index')); ?>">Presupuesto</a>
                <a href="<?php echo e(route('app.calendario')); ?>">Calendario</a>
                <a href="<?php echo e(route('app.proyecciones')); ?>">Proyecciones</a>
            </div>
        </div>
    <?php endif; ?>
    <?php echo $__env->make('layouts.partials.vendor-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html>
<?php /**PATH /Users/angelpenaloza/Documents/GitHub/finanzas/resources/views/layouts/app.blade.php ENDPATH**/ ?>