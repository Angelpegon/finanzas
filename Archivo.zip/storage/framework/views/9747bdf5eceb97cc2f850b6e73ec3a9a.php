<?php $__env->startSection('header-utils'); ?>
    <div class="dashboard-period d-none d-md-inline-flex" role="status">
        <?php echo $__env->make('layouts.partials.icon', ['name' => 'calendar', 'class' => 'ui-icon ui-icon--sm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <span>Mes actual</span>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php
    $v = $situacion['variaciones'] ?? [];
    $fmtVar = function (?float $pct, bool $positivoEsBueno = true): array {
        if ($pct === null) {
            return ['texto' => 'Sin base mes ant.', 'clase' => 'kpi-delta--flat', 'icono' => null];
        }
        $signo = $pct > 0 ? '+' : '';
        if ($pct == 0.0) {
            return [
                'texto' => '0% vs mes anterior',
                'clase' => 'kpi-delta--flat',
                'icono' => null,
            ];
        }
        $favorable = $positivoEsBueno ? ($pct > 0) : ($pct < 0);

        return [
            'texto' => $signo.number_format($pct, 1, ',', '.').'% vs mes anterior',
            'clase' => $favorable ? 'kpi-delta--up' : 'kpi-delta--down',
            'icono' => $pct > 0 ? 'arrow-up' : 'arrow-down',
        ];
    };
    $varIngresos = $fmtVar($v['ingresos_porcentaje'] ?? null, true);
    $varGastos = $fmtVar($v['gastos_porcentaje'] ?? null, false);
    $varPagos = $fmtVar($v['pagos_deuda_porcentaje'] ?? null, false);
    $varDisponible = $fmtVar($v['disponible_porcentaje'] ?? null, true);
?>

<div class="dashboard">
    <div class="dashboard-main">
        <div class="kpi-grid">
            <article class="kpi-card kpi-card--green">
                <div class="kpi-card__top">
                    <span class="kpi-card__label">Ingresos del mes</span>
                    <span class="kpi-card__icon"><?php echo $__env->make('layouts.partials.icon', ['name' => 'trending-up', 'class' => 'ui-icon'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></span>
                </div>
                <strong class="kpi-card__value"><?php echo \App\Support\Dinero::formatear($situacion['ingresos_mes_centavos']); ?></strong>
                <span class="kpi-delta <?php echo e($varIngresos['clase']); ?>">
                    <?php if($varIngresos['icono']): ?><?php echo $__env->make('layouts.partials.icon', ['name' => $varIngresos['icono'], 'class' => 'ui-icon ui-icon--xs'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php endif; ?>
                    <?php echo e($varIngresos['texto']); ?>

                </span>
            </article>
            <article class="kpi-card kpi-card--red">
                <div class="kpi-card__top">
                    <span class="kpi-card__label">Gastos del mes</span>
                    <span class="kpi-card__icon"><?php echo $__env->make('layouts.partials.icon', ['name' => 'wallet', 'class' => 'ui-icon'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></span>
                </div>
                <strong class="kpi-card__value"><?php echo \App\Support\Dinero::formatear($situacion['gastos_mes_centavos']); ?></strong>
                <span class="kpi-delta <?php echo e($varGastos['clase']); ?>">
                    <?php if($varGastos['icono']): ?><?php echo $__env->make('layouts.partials.icon', ['name' => $varGastos['icono'], 'class' => 'ui-icon ui-icon--xs'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php endif; ?>
                    <?php echo e($varGastos['texto']); ?>

                </span>
            </article>
            <article class="kpi-card kpi-card--amber">
                <div class="kpi-card__top">
                    <span class="kpi-card__label">Pagos de deudas</span>
                    <span class="kpi-card__icon"><?php echo $__env->make('layouts.partials.icon', ['name' => 'credit-card', 'class' => 'ui-icon'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></span>
                </div>
                <strong class="kpi-card__value"><?php echo \App\Support\Dinero::formatear($situacion['pagos_deuda_mes_centavos']); ?></strong>
                <span class="kpi-delta <?php echo e($varPagos['clase']); ?>">
                    <?php if($varPagos['icono']): ?><?php echo $__env->make('layouts.partials.icon', ['name' => $varPagos['icono'], 'class' => 'ui-icon ui-icon--xs'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php endif; ?>
                    <?php echo e($varPagos['texto']); ?>

                </span>
            </article>
            <article class="kpi-card kpi-card--blue">
                <div class="kpi-card__top">
                    <span class="kpi-card__label">Disponible</span>
                    <span class="kpi-card__icon"><?php echo $__env->make('layouts.partials.icon', ['name' => 'banknote', 'class' => 'ui-icon'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></span>
                </div>
                <strong class="kpi-card__value"><?php echo \App\Support\Dinero::formatear($situacion['dinero_disponible_real_centavos']); ?></strong>
                <span class="kpi-delta <?php echo e($varDisponible['clase']); ?>">
                    <?php if($varDisponible['icono']): ?><?php echo $__env->make('layouts.partials.icon', ['name' => $varDisponible['icono'], 'class' => 'ui-icon ui-icon--xs'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php endif; ?>
                    <?php echo e($varDisponible['texto']); ?>

                </span>
            </article>
        </div>

        <div class="dash-row dash-row--3">
            <section class="dash-card">
                <div class="dash-card__head">
                    <h2>Próximos pagos</h2>
                    <a href="<?php echo e(route('app.calendario')); ?>">Ver todo</a>
                </div>
                <div class="dash-list">
                    <?php $__empty_1 = true; $__currentLoopData = $situacion['proximos_vencimientos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $nombre = $evento->prestamo?->nombre
                                ?? $evento->compra?->tarjetaCredito?->nombre
                                ?? 'Obligación';
                        ?>
                        <div class="dash-list__row">
                            <span class="dash-list__icon dash-list__icon--amber"><?php echo $__env->make('layouts.partials.icon', ['name' => 'file-invoice', 'class' => 'ui-icon ui-icon--sm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></span>
                            <div class="dash-list__body">
                                <strong><?php echo e($nombre); ?></strong>
                                <small>Cuota <?php echo e($evento->numero); ?> · <?php echo e($evento->fecha_vencimiento->format('d M')); ?></small>
                            </div>
                            <strong class="dash-list__amount text-danger"><?php echo \App\Support\Dinero::formatear($evento->total_centavos); ?></strong>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-secondary mb-0">Sin vencimientos en 30 días.</p>
                    <?php endif; ?>
                </div>
            </section>

            <section class="dash-card">
                <div class="dash-card__head">
                    <h2>Presupuesto</h2>
                    <a href="<?php echo e(route('app.presupuestos.index')); ?>">Gestionar</a>
                </div>
                <div class="dash-list">
                    <?php $__empty_1 = true; $__currentLoopData = $situacion['presupuesto_lineas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $linea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php $pct = min(100, (float) $linea->porcentaje_consumido); ?>
                        <div class="budget-row">
                            <div class="d-flex justify-content-between gap-2">
                                <strong><?php echo e($linea->categoria->nombre); ?></strong>
                                <span class="<?php echo e($pct >= 100 ? 'text-danger' : 'text-secondary'); ?>"><?php echo e(number_format($pct, 0)); ?>%</span>
                            </div>
                            <div class="progress progress--thin mt-2">
                                <div class="progress-bar <?php echo e($pct >= 100 ? 'bg-danger' : ($pct >= 70 ? 'bg-warning' : 'bg-success')); ?>" style="width: <?php echo e($pct); ?>%"></div>
                            </div>
                            <small class="text-secondary"><?php echo \App\Support\Dinero::formatear($linea->gasto_real_centavos); ?> de <?php echo \App\Support\Dinero::formatear($linea->tope_centavos); ?></small>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-secondary mb-0">Aún no hay presupuesto este mes. <a href="<?php echo e(route('app.presupuestos.index')); ?>">Crear</a></p>
                    <?php endif; ?>
                </div>
            </section>

            <section class="dash-card">
                <div class="dash-card__head">
                    <h2>Metas de ahorro</h2>
                    <a href="<?php echo e(route('app.metas.index')); ?>">Ver metas</a>
                </div>
                <div class="dash-list">
                    <?php $__empty_1 = true; $__currentLoopData = $situacion['metas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="goal-row">
                            <div class="d-flex justify-content-between gap-2">
                                <div>
                                    <strong><?php echo e($meta->nombre); ?></strong>
                                    <small class="d-block text-secondary"><?php echo \App\Support\Dinero::formatear($meta->progreso_centavos); ?> / <?php echo \App\Support\Dinero::formatear($meta->objetivo_centavos); ?></small>
                                </div>
                                <span><?php echo e($meta->porcentaje_completado); ?>%</span>
                            </div>
                            <div class="progress progress--thin mt-2">
                                <div class="progress-bar bg-info" style="width: <?php echo e(min(100, $meta->porcentaje_completado)); ?>%"></div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p class="text-secondary mb-0">Sin metas activas. <a href="<?php echo e(route('app.metas.index')); ?>">Crear meta</a></p>
                    <?php endif; ?>
                </div>
            </section>
        </div>

        <div class="dash-row dash-row--2">
            <section class="dash-card">
                <div class="dash-card__head">
                    <h2>Detalle de deuda</h2>
                    <?php if(($situacion['detalle_deuda']['tipo'] ?? null) === 'tarjeta'): ?>
                        <a href="<?php echo e(route('app.tarjetas.index')); ?>">Tarjetas</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('app.deudas.index')); ?>">Deudas</a>
                    <?php endif; ?>
                </div>
                <?php if($situacion['detalle_deuda'] ?? null): ?>
                    <?php $d = $situacion['detalle_deuda']; ?>
                    <div class="debt-detail">
                        <div class="d-flex justify-content-between align-items-start gap-2 mb-3">
                            <div class="d-flex align-items-center gap-2">
                                <span class="dash-list__icon dash-list__icon--amber"><?php echo $__env->make('layouts.partials.icon', ['name' => 'credit-card', 'class' => 'ui-icon ui-icon--sm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></span>
                                <div>
                                    <strong><?php echo e($d['nombre']); ?></strong>
                                    <small class="d-block text-secondary text-capitalize"><?php echo e($d['tipo']); ?></small>
                                </div>
                            </div>
                            <span class="status-pill"><?php echo e($d['estado']); ?></span>
                        </div>
                        <p class="debt-detail__saldo mb-1"><?php echo \App\Support\Dinero::formatear($d['saldo_centavos']); ?></p>
                        <small class="text-secondary">Saldo actual · <?php echo e($d['avance_porcentaje']); ?>% avanzado</small>
                        <div class="progress progress--thin mt-2 mb-3">
                            <div class="progress-bar bg-warning" style="width: <?php echo e(min(100, $d['avance_porcentaje'])); ?>%"></div>
                        </div>
                        <div class="debt-detail__stats">
                            <div><span>Cuota</span><strong><?php echo \App\Support\Dinero::formatear($d['cuota_centavos']); ?></strong></div>
                            <div><span>Tasa EA</span><strong><?php echo e(number_format($d['ea_porcentaje'], 2, ',', '.')); ?>%</strong></div>
                            <?php if($d['cuotas_pagadas'] !== null): ?>
                                <div><span>Cuotas</span><strong><?php echo e($d['cuotas_pagadas']); ?>/<?php echo e($d['cuotas_total']); ?></strong></div>
                            <?php endif; ?>
                            <div><span>Próximo pago</span><strong><?php echo e($d['proximo_pago'] ? \Carbon\Carbon::parse($d['proximo_pago'])->format('d/m/Y') : '—'); ?></strong></div>
                        </div>
                    </div>
                <?php else: ?>
                    <p class="text-secondary mb-0">No tienes deudas activas con saldo.</p>
                <?php endif; ?>
            </section>

            <section class="dash-card">
                <div class="dash-card__head">
                    <h2>Calendario financiero</h2>
                    <a href="<?php echo e(route('app.calendario')); ?>"><?php echo e($situacion['calendario_grilla']['etiqueta'] ?? ''); ?></a>
                </div>
                <div class="mini-cal">
                    <div class="mini-cal__weekdays">
                        <?php $__currentLoopData = ['L','M','X','J','V','S','D']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span><?php echo e($wd); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="mini-cal__grid">
                        <?php $__currentLoopData = $situacion['calendario_grilla']['celdas'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $celda): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($celda === null): ?>
                                <div class="mini-cal__cell mini-cal__cell--empty"></div>
                            <?php else: ?>
                                <div class="mini-cal__cell <?php echo e($celda['hoy'] ? 'is-today' : ''); ?> <?php echo e($celda['tiene_pago'] ? 'has-pago' : ''); ?> <?php echo e($celda['tiene_ingreso'] ? 'has-ingreso' : ''); ?>" title="<?php echo e(collect($celda['eventos'])->pluck('descripcion')->join(' · ')); ?>">
                                    <span class="mini-cal__day"><?php echo e($celda['dia']); ?></span>
                                    <?php if(count($celda['eventos']) > 0): ?>
                                        <span class="mini-cal__dots">
                                            <?php if($celda['tiene_ingreso']): ?><i class="dot dot--green"></i><?php endif; ?>
                                            <?php if($celda['tiene_pago']): ?><i class="dot dot--red"></i><?php endif; ?>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </section>
        </div>
    </div>

    <aside class="dashboard-rail">
        <section class="dash-card">
            <div class="dash-card__head">
                <h2>Cuentas</h2>
                <a class="btn-chip" href="<?php echo e(route('app.cuentas.create')); ?>">+ Nueva</a>
            </div>
            <div class="dash-list">
                <?php $__empty_1 = true; $__currentLoopData = $situacion['cuentas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuenta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="dash-list__row">
                        <span class="dash-list__icon"><?php echo e(strtoupper(substr($cuenta['nombre'], 0, 1))); ?></span>
                        <div class="dash-list__body">
                            <strong><?php echo e($cuenta['nombre']); ?></strong>
                            <small><?php echo e(ucfirst($cuenta['tipo'])); ?><?php if($cuenta['institucion']): ?> · <?php echo e($cuenta['institucion']); ?><?php endif; ?></small>
                        </div>
                        <strong><?php echo \App\Support\Dinero::formatear($cuenta['saldo_centavos']); ?></strong>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-secondary mb-0">Sin cuentas. <a href="<?php echo e(route('app.cuentas.create')); ?>">Crear</a></p>
                <?php endif; ?>
            </div>
            <?php if(($situacion['cuentas'] ?? collect())->isNotEmpty()): ?>
                <div class="rail-total">
                    <span>Total en cuentas</span>
                    <strong><?php echo \App\Support\Dinero::formatear($situacion['total_cuentas_centavos']); ?></strong>
                </div>
            <?php endif; ?>
        </section>

        <section class="dash-card">
            <div class="dash-card__head">
                <h2>Movimientos recientes</h2>
            </div>
            <div class="filter-tabs" data-mov-tabs>
                <button type="button" class="is-active" data-mov-filter="todos">Todos</button>
                <button type="button" data-mov-filter="ingreso">Ingresos</button>
                <button type="button" data-mov-filter="gasto">Gastos</button>
                <button type="button" data-mov-filter="transferencia">Transfer.</button>
            </div>
            <div class="dash-list" data-mov-list>
                <?php $__empty_1 = true; $__currentLoopData = $situacion['movimientos_recientes']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mov): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="dash-list__row" data-mov-tipo="<?php echo e($mov['tipo'] === 'aporte_meta' ? 'transferencia' : $mov['tipo']); ?>">
                        <span class="dash-list__icon <?php echo e($mov['signo'] > 0 ? 'dash-list__icon--green' : ($mov['signo'] < 0 ? 'dash-list__icon--red' : '')); ?>">
                            <?php echo $__env->make('layouts.partials.icon', ['name' => $mov['signo'] > 0 ? 'arrow-up' : ($mov['signo'] < 0 ? 'arrow-down' : 'exchange'), 'class' => 'ui-icon ui-icon--sm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </span>
                        <div class="dash-list__body">
                            <strong><?php echo e($mov['descripcion']); ?></strong>
                            <small><?php echo e(ucfirst(str_replace('_', ' ', $mov['tipo']))); ?><?php if($mov['categoria']): ?> · <?php echo e($mov['categoria']); ?><?php endif; ?> · <?php echo e(\Carbon\Carbon::parse($mov['fecha'])->format('d/m')); ?></small>
                        </div>
                        <strong class="<?php echo e($mov['signo'] > 0 ? 'text-success' : ($mov['signo'] < 0 ? 'text-danger' : '')); ?>">
                            <?php echo e($mov['signo'] > 0 ? '+' : ($mov['signo'] < 0 ? '-' : '')); ?><?php echo \App\Support\Dinero::formatear($mov['monto_centavos']); ?>
                        </strong>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-secondary mb-0">Aún no hay movimientos.</p>
                <?php endif; ?>
            </div>
        </section>

        <section class="dash-card">
            <div class="dash-card__head"><h2>Acciones rápidas</h2></div>
            <div class="quick-grid">
                <a href="<?php echo e(route('app.ingresos.create')); ?>" class="quick-tile quick-tile--green"><span><?php echo $__env->make('layouts.partials.icon', ['name' => 'arrow-up', 'class' => 'ui-icon'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></span>Nuevo ingreso</a>
                <a href="<?php echo e(route('app.gastos.create')); ?>" class="quick-tile quick-tile--red"><span><?php echo $__env->make('layouts.partials.icon', ['name' => 'arrow-down', 'class' => 'ui-icon'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></span>Nuevo gasto</a>
                <a href="<?php echo e(route('app.pagos.index')); ?>" class="quick-tile quick-tile--purple"><span><?php echo $__env->make('layouts.partials.icon', ['name' => 'exchange', 'class' => 'ui-icon'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></span>Transferencia</a>
                <a href="<?php echo e(route('app.metas.index')); ?>" class="quick-tile quick-tile--blue"><span><?php echo $__env->make('layouts.partials.icon', ['name' => 'piggy-bank', 'class' => 'ui-icon'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></span>Nueva meta</a>
                <a href="<?php echo e(route('app.presupuestos.index')); ?>" class="quick-tile quick-tile--amber"><span><?php echo $__env->make('layouts.partials.icon', ['name' => 'percent', 'class' => 'ui-icon'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></span>Presupuesto</a>
                <a href="<?php echo e(route('app.deudas.create')); ?>" class="quick-tile quick-tile--amber"><span><?php echo $__env->make('layouts.partials.icon', ['name' => 'file-invoice', 'class' => 'ui-icon'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></span>Nuevo crédito</a>
                <a href="<?php echo e(route('app.pagos.index')); ?>" class="quick-tile quick-tile--green"><span><?php echo $__env->make('layouts.partials.icon', ['name' => 'banknote', 'class' => 'ui-icon'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></span>Nuevo pago</a>
                <a href="<?php echo e(route('app.proyecciones')); ?>" class="quick-tile quick-tile--purple"><span><?php echo $__env->make('layouts.partials.icon', ['name' => 'chart-line', 'class' => 'ui-icon'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></span>Proyecciones</a>
            </div>
        </section>
    </aside>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', [
    'title' => 'Dashboard',
    'heading' => 'Dashboard',
    'subtitle' => 'Resumen de tu situación financiera',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/angelpenaloza/Documents/GitHub/finanzas/resources/views/situacion.blade.php ENDPATH**/ ?>