<script src="<?php echo e(asset('assets/css/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/sweetalert.js')); ?>"></script>
<?php /**PATH /Users/angelpenaloza/Documents/GitHub/finanzas/resources/views/layouts/partials/vendor-scripts.blade.php ENDPATH**/ ?>