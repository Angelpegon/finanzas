<?php $__env->startSection('content'); ?>
<?php
    $errXfer = $errors->transferencia;
    $errPago = $errors->pago;
    $oldXfer = $errXfer->any();
    $oldPago = $errPago->any();
    $modoPago = $oldPago || request()->boolean('pago');
?>

<div class="capture-flow">
    <nav class="flow-tabs" aria-label="Tipo de movimiento">
        <a href="<?php echo e(route('app.pagos.index')); ?>" class="<?php echo e(! $modoPago ? 'is-active' : ''); ?>">Transferir</a>
        <a href="<?php echo e(route('app.pagos.index', ['pago' => 1])); ?>" class="<?php echo e($modoPago ? 'is-active' : ''); ?>">Registrar pago</a>
    </nav>

    <?php if(! $modoPago): ?>
        <?php if($cuentas->count() >= 2): ?>
        <form method="POST" action="<?php echo e(route('app.transferencias.store')); ?>" class="dash-card form-panel" novalidate>
            <?php echo csrf_field(); ?>
            <div class="form-section__head">
                <p class="form-section__eyebrow">Entre cuentas</p>
                <h2 class="form-section__title">Transferir liquidez</h2>
            </div>
            <?php echo $__env->make('layouts.partials.form-errors', ['bag' => 'transferencia'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="money-hero">
                <label class="form-label" for="monto_transferencia">Monto</label>
                <input id="monto_transferencia" name="monto" data-miles inputmode="decimal" value="<?php echo e($oldXfer ? old('monto') : ''); ?>" class="form-control form-control-lg <?php $__errorArgs = ['monto', 'transferencia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="0" required>
                <?php echo $__env->make('layouts.partials.field-error', ['name' => 'monto', 'bag' => 'transferencia'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>

            <section class="form-section">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label" for="cuenta_liquida_id">Origen</label>
                        <select id="cuenta_liquida_id" name="cuenta_liquida_id" class="form-select form-select-lg <?php $__errorArgs = ['cuenta_liquida_id', 'transferencia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                            <option value="">Cuenta</option>
                            <?php $__currentLoopData = $cuentas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuenta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($cuenta->id); ?>" <?php if($oldXfer && old('cuenta_liquida_id') == $cuenta->id): echo 'selected'; endif; ?>><?php echo e($cuenta->nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php echo $__env->make('layouts.partials.field-error', ['name' => 'cuenta_liquida_id', 'bag' => 'transferencia'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label" for="cuenta_destino_id">Destino</label>
                        <select id="cuenta_destino_id" name="cuenta_destino_id" class="form-select form-select-lg <?php $__errorArgs = ['cuenta_destino_id', 'transferencia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                            <option value="">Cuenta</option>
                            <?php $__currentLoopData = $cuentas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuenta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($cuenta->id); ?>" <?php if($oldXfer && old('cuenta_destino_id') == $cuenta->id): echo 'selected'; endif; ?>><?php echo e($cuenta->nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php echo $__env->make('layouts.partials.field-error', ['name' => 'cuenta_destino_id', 'bag' => 'transferencia'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
                <div>
                    <label class="form-label" for="fecha_transferencia">Fecha</label>
                    <input id="fecha_transferencia" name="fecha" type="date" value="<?php echo e($oldXfer ? old('fecha', now()->toDateString()) : now()->toDateString()); ?>" class="form-control form-control-lg <?php $__errorArgs = ['fecha', 'transferencia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                    <?php echo $__env->make('layouts.partials.field-error', ['name' => 'fecha', 'bag' => 'transferencia'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div>
                    <label class="form-label" for="descripcion_transferencia">Descripción <span class="text-secondary">(opcional)</span></label>
                    <input id="descripcion_transferencia" name="descripcion" value="<?php echo e($oldXfer ? old('descripcion') : ''); ?>" class="form-control form-control-lg <?php $__errorArgs = ['descripcion', 'transferencia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Motivo del traslado">
                    <?php echo $__env->make('layouts.partials.field-error', ['name' => 'descripcion', 'bag' => 'transferencia'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </section>

            <div class="form-actions">
                <button class="btn btn-primary btn-lg w-100" type="submit">Contabilizar transferencia</button>
            </div>
        </form>
        <?php else: ?>
            <div class="alert alert-light empty-state">Crea al menos dos cuentas líquidas para transferir entre ellas. <a href="<?php echo e(route('app.cuentas.create')); ?>">Nueva cuenta</a></div>
        <?php endif; ?>
    <?php else: ?>
        <form method="POST" action="<?php echo e(route('app.pagos.store')); ?>" class="dash-card form-panel" novalidate>
            <?php echo csrf_field(); ?>
            <div class="form-section__head">
                <p class="form-section__eyebrow">Salida</p>
                <h2 class="form-section__title">Registrar un pago</h2>
            </div>
            <?php echo $__env->make('layouts.partials.form-errors', ['bag' => 'pago'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="money-hero">
                <label class="form-label" for="monto_pago">Monto</label>
                <input id="monto_pago" name="monto" data-miles inputmode="decimal" value="<?php echo e($oldPago ? old('monto') : ''); ?>" class="form-control form-control-lg <?php $__errorArgs = ['monto', 'pago'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="0" required>
                <?php echo $__env->make('layouts.partials.field-error', ['name' => 'monto', 'bag' => 'pago'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>

            <section class="form-section">
                <div class="row g-3">
                    <div class="col-6">
                        <label class="form-label" for="tipo">Tipo</label>
                        <select id="tipo" name="tipo" class="form-select form-select-lg <?php $__errorArgs = ['tipo', 'pago'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                            <?php $__currentLoopData = ['gasto'=>'Gasto','servicio'=>'Servicio','deuda_personal'=>'Deuda personal','otra_obligacion'=>'Otra obligación']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v=>$t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($v); ?>" <?php if(($oldPago ? old('tipo') : 'gasto') === $v): echo 'selected'; endif; ?>><?php echo e($t); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php echo $__env->make('layouts.partials.field-error', ['name' => 'tipo', 'bag' => 'pago'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="col-6">
                        <label class="form-label" for="fecha_pago">Fecha</label>
                        <input id="fecha_pago" name="fecha" type="date" value="<?php echo e($oldPago ? old('fecha', now()->toDateString()) : now()->toDateString()); ?>" class="form-control form-control-lg <?php $__errorArgs = ['fecha', 'pago'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <?php echo $__env->make('layouts.partials.field-error', ['name' => 'fecha', 'bag' => 'pago'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
                <div>
                    <label class="form-label" for="cuenta_pago">Cuenta utilizada</label>
                    <select id="cuenta_pago" name="cuenta_liquida_id" class="form-select form-select-lg <?php $__errorArgs = ['cuenta_liquida_id', 'pago'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <option value="">Selecciona una cuenta</option>
                        <?php $__currentLoopData = $cuentas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuenta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cuenta->id); ?>" <?php if($oldPago && old('cuenta_liquida_id') == $cuenta->id): echo 'selected'; endif; ?>><?php echo e($cuenta->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php echo $__env->make('layouts.partials.field-error', ['name' => 'cuenta_liquida_id', 'bag' => 'pago'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div>
                    <label class="form-label" for="categoria_id">Categoría de gasto</label>
                    <select id="categoria_id" name="categoria_id" class="form-select form-select-lg <?php $__errorArgs = ['categoria_id', 'pago'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <option value="">Obligatoria para gasto o servicio</option>
                        <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($categoria->id); ?>" <?php if($oldPago && old('categoria_id') == $categoria->id): echo 'selected'; endif; ?>><?php echo e($categoria->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php echo $__env->make('layouts.partials.field-error', ['name' => 'categoria_id', 'bag' => 'pago'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div>
                    <label class="form-label" for="destino">Destino</label>
                    <input id="destino" name="destino" value="<?php echo e($oldPago ? old('destino') : ''); ?>" class="form-control form-control-lg <?php $__errorArgs = ['destino', 'pago'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Proveedor, banco o persona" required>
                    <?php echo $__env->make('layouts.partials.field-error', ['name' => 'destino', 'bag' => 'pago'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div>
                    <label class="form-label" for="referencia">Referencia única</label>
                    <input id="referencia" name="referencia" value="<?php echo e($oldPago ? old('referencia') : ''); ?>" class="form-control form-control-lg <?php $__errorArgs = ['referencia', 'pago'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Factura o recibo" required>
                    <?php echo $__env->make('layouts.partials.field-error', ['name' => 'referencia', 'bag' => 'pago'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div>
                    <label class="form-label" for="observaciones">Observaciones <span class="text-secondary">(opcional)</span></label>
                    <textarea id="observaciones" name="observaciones" class="form-control <?php $__errorArgs = ['observaciones', 'pago'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="2" placeholder="Detalle adicional"><?php echo e($oldPago ? old('observaciones') : ''); ?></textarea>
                    <?php echo $__env->make('layouts.partials.field-error', ['name' => 'observaciones', 'bag' => 'pago'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </section>

            <div class="form-actions">
                <button class="btn btn-primary btn-lg w-100" type="submit">Guardar pago</button>
            </div>
        </form>
    <?php endif; ?>

    <div class="list-block">
        <div class="list-block__head">
            <h2>Transferencias recientes</h2>
            <span><?php echo e($transferencias->count()); ?></span>
        </div>
        <div class="card-stack">
        <?php $__empty_1 = true; $__currentLoopData = $transferencias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <article class="account-card">
            <div class="account-card__main">
                <div class="account-card__icon"><?php echo $__env->make('layouts.partials.icon', ['name' => 'exchange', 'class' => 'ui-icon ui-icon--sm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                <div class="account-card__body">
                    <div class="account-card__head">
                        <div class="account-card__title">
                            <h2><?php echo e($t->descripcion ?: ucfirst(str_replace('_',' ', $t->tipo->value))); ?></h2>
                            <small><?php echo e($t->fecha->format('d/m/Y')); ?> · <?php echo e($t->cuentaLiquida?->nombre); ?></small>
                        </div>
                        <strong class="account-card__amount"><?php echo \App\Support\Dinero::formatear($t->monto_centavos); ?></strong>
                    </div>
                </div>
            </div>
        </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="alert alert-light empty-state">Aún no hay transferencias.</div>
        <?php endif; ?>
        </div>
    </div>

    <div class="list-block">
        <div class="list-block__head">
            <h2>Historial de pagos</h2>
            <span><?php echo e($pagos->count()); ?></span>
        </div>
        <div class="card-stack">
        <?php $__empty_1 = true; $__currentLoopData = $pagos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <article class="account-card">
            <div class="account-card__main">
                <div class="account-card__icon"><?php echo $__env->make('layouts.partials.icon', ['name' => 'arrow-down', 'class' => 'ui-icon ui-icon--sm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                <div class="account-card__body">
                    <div class="account-card__head">
                        <div class="account-card__title">
                            <h2><?php echo e($pago->destino); ?></h2>
                            <small><?php echo e(ucfirst($pago->tipo)); ?> · <?php echo e($pago->fecha->format('d/m/Y')); ?></small>
                        </div>
                        <strong class="account-card__amount"><?php echo \App\Support\Dinero::formatear($pago->monto_centavos); ?></strong>
                    </div>
                    <div class="small text-secondary mt-1">Ref. <?php echo e($pago->referencia); ?> · <?php echo e($pago->cuentaLiquida?->nombre); ?></div>
                </div>
            </div>
        </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="alert alert-light empty-state">Aún no hay pagos registrados.</div>
        <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', [
    'title' => 'Transferencias y pagos',
    'heading' => 'Movimientos',
    'subtitle' => 'Cada operación postea el libro. Las deudas se pagan en sus módulos.',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/angelpenaloza/Documents/GitHub/finanzas/resources/views/pagos/index.blade.php ENDPATH**/ ?>