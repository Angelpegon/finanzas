<?php
    use App\Support\InstitucionFinanciera;

    $valor = $valor ?? null;
    $fallbackIcon = $fallbackIcon ?? 'wallet';
    $sizeClass = $sizeClass ?? '';
    $logo = InstitucionFinanciera::rutaLogo($valor);
    $etiqueta = InstitucionFinanciera::etiqueta($valor);
    $inicial = InstitucionFinanciera::inicial($valor);
?>
<?php if($logo): ?>
    <span class="brand-icon <?php echo e($sizeClass); ?>" title="<?php echo e($etiqueta); ?>">
        <img
            src="<?php echo e($logo); ?>"
            alt="<?php echo e($etiqueta); ?>"
            loading="lazy"
            decoding="async"
            referrerpolicy="no-referrer"
            onerror="this.style.display='none';var p=this.parentElement;p.classList.add('brand-icon--fallback');var f=p.querySelector('[data-brand-fallback]');if(f){f.hidden=false;}"
        >
        <span class="brand-icon__glyph" data-brand-fallback hidden aria-hidden="true"><?php echo e($inicial); ?></span>
    </span>
<?php elseif($etiqueta !== ''): ?>
    <span class="brand-icon brand-icon--fallback <?php echo e($sizeClass); ?>" title="<?php echo e($etiqueta); ?>" aria-hidden="true">
        <span class="brand-icon__glyph"><?php echo e($inicial); ?></span>
    </span>
<?php else: ?>
    <span class="account-card__icon <?php echo e($sizeClass); ?>"><?php echo $__env->make('layouts.partials.icon', ['name' => $fallbackIcon, 'class' => 'ui-icon ui-icon--sm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></span>
<?php endif; ?>
<?php /**PATH /Users/angelpenaloza/Documents/GitHub/finanzas/resources/views/layouts/partials/institucion-icon.blade.php ENDPATH**/ ?>