<?php $__env->startSection('content'); ?>
<div class="capture-flow capture-flow--wide">
    <?php echo $__env->make('layouts.partials.form-errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <form method="POST" action="<?php echo e(route('app.presupuestos.store')); ?>" class="dash-card form-panel" novalidate>
        <?php echo csrf_field(); ?>
        <div class="form-section__head">
            <p class="form-section__eyebrow">Mes</p>
            <h2 class="form-section__title">Definir topes</h2>
        </div>

        <section class="form-section">
            <div class="row g-3">
                <div class="col-6">
                    <label class="form-label" for="anio">Año</label>
                    <input id="anio" name="anio" type="number" min="2020" max="2100" value="<?php echo e(old('anio', now()->year)); ?>" class="form-control form-control-lg <?php $__errorArgs = ['anio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                    <?php echo $__env->make('layouts.partials.field-error', ['name' => 'anio'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="col-6">
                    <label class="form-label" for="mes">Mes</label>
                    <select id="mes" name="mes" class="form-select form-select-lg <?php $__errorArgs = ['mes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <?php $__currentLoopData = range(1,12); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($mes); ?>" <?php if(old('mes', now()->month) == $mes): echo 'selected'; endif; ?>><?php echo e(\Carbon\Carbon::create()->month($mes)->locale('es')->monthName); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php echo $__env->make('layouts.partials.field-error', ['name' => 'mes'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
            <div>
                <label class="form-label">Alertar al alcanzar (%)</label>
                <div class="d-flex flex-wrap gap-3">
                    <?php $__currentLoopData = [70,80,90,100]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $umbral): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label class="form-check">
                            <input class="form-check-input" type="checkbox" name="umbrales[]" value="<?php echo e($umbral); ?>" <?php if(in_array($umbral, old('umbrales', $presupuesto?->umbrales_alerta ?? [70,80,90,100]))): echo 'checked'; endif; ?>>
                            <?php echo e($umbral); ?>%
                        </label>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php echo $__env->make('layouts.partials.field-error', ['name' => 'umbrales'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </section>

        <section class="form-section">
            <div class="form-section__head">
                <p class="form-section__eyebrow">Categorías</p>
                <h2 class="form-section__title">Monto presupuestado</h2>
            </div>
            <?php echo $__env->make('layouts.partials.field-error', ['name' => 'lineas'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="budget-lines">
                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php ($lineaExistente = $presupuesto?->lineas->firstWhere('categoria_id', $categoria->id)); ?>
                    <label class="budget-line">
                        <span class="budget-line__name"><?php echo e($categoria->nombre); ?></span>
                        <input name="lineas[]" type="text" inputmode="decimal" data-miles class="form-control budget-line__amount <?php $__errorArgs = ['lineas.'.$loop->index];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('lineas.'.$loop->index, $lineaExistente ? \App\Support\Dinero::centavosAPesos($lineaExistente->tope_centavos) : '')); ?>" placeholder="$ 0" autocomplete="off">
                        <input type="hidden" name="categoria_ids[]" value="<?php echo e($categoria->id); ?>">
                    </label>
                    <?php echo $__env->make('layouts.partials.field-error', ['name' => 'lineas.'.$loop->index], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>

        <div class="form-actions">
            <button class="btn btn-primary btn-lg w-100" type="submit">Guardar presupuesto</button>
        </div>
    </form>

    <?php if($presupuesto): ?>
    <div class="list-block">
        <div class="list-block__head">
            <h2>Seguimiento · <?php echo e(\Carbon\Carbon::create($presupuesto->anio, $presupuesto->mes)->locale('es')->monthName); ?></h2>
            <span><?php echo e($presupuesto->lineas->count()); ?> líneas</span>
        </div>
        <div class="card-stack">
        <?php $__currentLoopData = $presupuesto->lineas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $linea): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <article class="account-card">
            <div class="account-card__main">
                <div class="account-card__icon"><?php echo $__env->make('layouts.partials.icon', ['name' => 'percent', 'class' => 'ui-icon ui-icon--sm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                <div class="account-card__body">
                    <div class="account-card__head">
                        <div class="account-card__title">
                            <h2><?php echo e($linea->categoria->nombre); ?></h2>
                            <small>Presupuesto <?php echo \App\Support\Dinero::formatear($linea->tope_centavos); ?></small>
                        </div>
                        <strong class="account-card__amount"><?php echo \App\Support\Dinero::formatear($linea->gasto_real_centavos); ?></strong>
                    </div>
                    <div class="progress progress--thin mt-3"><div class="progress-bar" style="width: <?php echo e(min(100, $linea->porcentaje_consumido)); ?>%"></div></div>
                    <div class="small text-secondary mt-2">Real vs proyección: <?php echo \App\Support\Dinero::formatear($linea->gasto_real_centavos); ?> · <?php echo \App\Support\Dinero::formatear($linea->proyeccion_centavos); ?> · <?php echo e($linea->porcentaje_consumido); ?>%</div>
                    <?php if($linea->alertas): ?><div class="small text-danger mt-1">Alertas alcanzadas: <?php echo e(implode('%, ', $linea->alertas)); ?>%</div><?php endif; ?>
                </div>
            </div>
        </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
    <?php else: ?>
        <div class="alert alert-light empty-state">Aún no hay presupuesto para el mes actual.</div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', [
    'title' => 'Presupuesto',
    'heading' => 'Mi presupuesto',
    'subtitle' => 'Compara lo planeado, lo gastado y lo proyectado.',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/angelpenaloza/Documents/GitHub/finanzas/resources/views/presupuestos/index.blade.php ENDPATH**/ ?>