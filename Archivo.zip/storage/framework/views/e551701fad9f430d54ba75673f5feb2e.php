<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.partials.form-errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php
    $destinosActivos = $cuentas;
?>

<div class="list-block list-block--flush">
<div class="list-block__head">
    <h2>Activas</h2>
    <span><?php echo e($cuentas->count()); ?></span>
</div>
<div class="card-stack">
<?php $__empty_1 = true; $__currentLoopData = $cuentas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuenta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<article class="account-card">
    <div class="account-card__main">
        <div class="account-card__icon"><?php echo $__env->make('layouts.partials.icon', ['name' => 'wallet', 'class' => 'ui-icon ui-icon--sm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
        <div class="account-card__body">
            <div class="account-card__head">
                <div class="account-card__title">
                    <h2><?php echo e($cuenta->nombre); ?></h2>
                    <small><?php echo e(ucfirst($cuenta->tipo)); ?><?php if($cuenta->institucion): ?> · <?php echo e($cuenta->institucion); ?><?php endif; ?></small>
                </div>
                <strong class="account-card__amount"><?php echo \App\Support\Dinero::formatear($cuenta->saldo_actual_centavos); ?></strong>
            </div>
            <div class="account-card__actions mt-2">
                <form method="POST" action="<?php echo e(route('app.cuentas.destroy', $cuenta)); ?>" class="d-inline" data-swal-confirm data-swal-title="¿Archivar esta cuenta?" data-swal-text="Deja de verse en tesorería activa. Puedes restaurarla después. El libro no se borra." data-swal-icon="warning" data-swal-confirm-text="Archivar">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <button class="card-btn card-btn--warn" type="submit">
                        <?php echo $__env->make('layouts.partials.icon', ['name' => 'archive', 'class' => 'ui-icon ui-icon--xs'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        Archivar
                    </button>
                </form>
                <button type="button" class="card-btn card-btn--muted" data-bs-toggle="collapse" data-bs-target="#cancelar-<?php echo e($cuenta->id); ?>" aria-expanded="false">
                    <?php echo $__env->make('layouts.partials.icon', ['name' => 'ban', 'class' => 'ui-icon ui-icon--xs'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    Cancelar…
                </button>
            </div>
            <div class="collapse mt-3" id="cancelar-<?php echo e($cuenta->id); ?>">
                <?php echo $__env->make('cuentas.partials.cancelar-form', [
                    'cuenta' => $cuenta,
                    'destinos' => $destinosActivos->where('id', '!=', $cuenta->id),
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
</article>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="alert alert-light empty-state">Aún no tienes cuentas activas. <a href="<?php echo e(route('app.cuentas.create')); ?>">Crear una</a>.</div>
<?php endif; ?>
</div>
</div>

<div class="list-block">
<div class="list-block__head">
    <h2>Archivadas</h2>
    <span><?php echo e($archivadas->count()); ?></span>
</div>
<div class="card-stack">
<?php $__empty_1 = true; $__currentLoopData = $archivadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuenta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<article class="account-card">
    <div class="account-card__main">
        <div class="account-card__icon"><?php echo $__env->make('layouts.partials.icon', ['name' => 'wallet', 'class' => 'ui-icon ui-icon--sm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
        <div class="account-card__body">
            <div class="account-card__head">
                <div class="account-card__title">
                    <h2><?php echo e($cuenta->nombre); ?></h2>
                    <small>Archivada · <?php echo e(ucfirst($cuenta->tipo)); ?><?php if($cuenta->institucion): ?> · <?php echo e($cuenta->institucion); ?><?php endif; ?></small>
                </div>
                <strong class="account-card__amount"><?php echo \App\Support\Dinero::formatear($cuenta->saldo_actual_centavos); ?></strong>
            </div>
            <div class="account-card__actions mt-2">
                <form method="POST" action="<?php echo e(route('app.cuentas.restore', $cuenta)); ?>" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <button class="card-btn card-btn--ok" type="submit">
                        <?php echo $__env->make('layouts.partials.icon', ['name' => 'restore', 'class' => 'ui-icon ui-icon--xs'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        Restaurar
                    </button>
                </form>
                <button type="button" class="card-btn card-btn--muted" data-bs-toggle="collapse" data-bs-target="#cancelar-arch-<?php echo e($cuenta->id); ?>" aria-expanded="false">
                    <?php echo $__env->make('layouts.partials.icon', ['name' => 'ban', 'class' => 'ui-icon ui-icon--xs'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    Cancelar…
                </button>
            </div>
            <div class="collapse mt-3" id="cancelar-arch-<?php echo e($cuenta->id); ?>">
                <?php echo $__env->make('cuentas.partials.cancelar-form', [
                    'cuenta' => $cuenta,
                    'destinos' => $destinosActivos,
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
</article>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="alert alert-light empty-state mb-0">No hay cuentas archivadas.</div>
<?php endif; ?>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', [
    'title' => 'Cuentas',
    'heading' => 'Mis cuentas',
    'subtitle' => 'Tu dinero, en un solo lugar.',
    'actionUrl' => route('app.cuentas.create'),
    'actionLabel' => 'Nueva cuenta',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/angelpenaloza/Documents/GitHub/finanzas/resources/views/cuentas/index.blade.php ENDPATH**/ ?>