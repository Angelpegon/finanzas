<div class="header-alerts" data-alerts>
    <button
        type="button"
        class="header-bell"
        data-bs-toggle="offcanvas"
        data-bs-target="#alerts-sheet"
        aria-controls="alerts-sheet"
        aria-label="Alertas<?php echo e(($alertasCount ?? 0) > 0 ? ' ('.($alertasCount ?? 0).')' : ''); ?>"
    >
        <?php echo $__env->make('layouts.partials.icon', ['name' => 'bell', 'class' => 'ui-icon'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php if(($alertasCount ?? 0) > 0): ?>
            <span class="header-bell__badge"><?php echo e($alertasCount > 9 ? '9+' : $alertasCount); ?></span>
        <?php endif; ?>
    </button>
</div>
<?php /**PATH /Users/angelpenaloza/Documents/GitHub/finanzas/resources/views/layouts/partials/alerts-bell.blade.php ENDPATH**/ ?>