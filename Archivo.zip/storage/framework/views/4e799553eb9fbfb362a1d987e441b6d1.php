<?php $__env->startSection('content'); ?>
<?php
    $errMeta = $errors->meta;
    $errAporte = $errors->aporte;
    $oldMeta = $errMeta->any();
    $oldAporte = $errAporte->any();
    $modoAporte = $oldAporte || request()->boolean('aporte');
?>

<div class="capture-flow">
    <nav class="flow-tabs" aria-label="Acción de metas">
        <a href="<?php echo e(route('app.metas.index')); ?>" class="<?php echo e(! $modoAporte ? 'is-active' : ''); ?>">Nueva meta</a>
        <a href="<?php echo e(route('app.metas.index', ['aporte' => 1])); ?>" class="<?php echo e($modoAporte ? 'is-active' : ''); ?>">Aportar</a>
    </nav>

    <?php if(! $modoAporte): ?>
        <form method="POST" action="<?php echo e(route('app.metas.store')); ?>" class="dash-card form-panel" novalidate>
            <?php echo csrf_field(); ?>
            <div class="form-section__head">
                <p class="form-section__eyebrow">Objetivo</p>
                <h2 class="form-section__title">Crear una meta</h2>
            </div>
            <?php echo $__env->make('layouts.partials.form-errors', ['bag' => 'meta'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="money-hero">
                <label class="form-label" for="objetivo">Monto objetivo</label>
                <input id="objetivo" name="objetivo" data-miles inputmode="decimal" value="<?php echo e($oldMeta ? old('objetivo') : ''); ?>" class="form-control form-control-lg <?php $__errorArgs = ['objetivo', 'meta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="0" required>
                <?php echo $__env->make('layouts.partials.field-error', ['name' => 'objetivo', 'bag' => 'meta'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>

            <section class="form-section">
                <div>
                    <label class="form-label" for="nombre">Nombre de la meta</label>
                    <input id="nombre" name="nombre" value="<?php echo e($oldMeta ? old('nombre') : ''); ?>" class="form-control form-control-lg <?php $__errorArgs = ['nombre', 'meta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Ej. Fondo de emergencia" required>
                    <?php echo $__env->make('layouts.partials.field-error', ['name' => 'nombre', 'bag' => 'meta'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="row g-3">
                    <div class="col-6">
                        <label class="form-label" for="aporte_mensual">Ahorro mensual planificado</label>
                        <input id="aporte_mensual" name="aporte_mensual" data-miles inputmode="decimal" value="<?php echo e($oldMeta ? old('aporte_mensual', 0) : 0); ?>" class="form-control form-control-lg <?php $__errorArgs = ['aporte_mensual', 'meta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php echo $__env->make('layouts.partials.field-error', ['name' => 'aporte_mensual', 'bag' => 'meta'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="col-6">
                        <label class="form-label" for="fecha_objetivo">Fecha objetivo</label>
                        <input id="fecha_objetivo" name="fecha_objetivo" type="date" value="<?php echo e($oldMeta ? old('fecha_objetivo') : ''); ?>" class="form-control form-control-lg <?php $__errorArgs = ['fecha_objetivo', 'meta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <?php echo $__env->make('layouts.partials.field-error', ['name' => 'fecha_objetivo', 'bag' => 'meta'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
                <div>
                    <label class="form-label" for="cuenta_liquida_id">Cuenta de referencia</label>
                    <select id="cuenta_liquida_id" name="cuenta_liquida_id" class="form-select form-select-lg <?php $__errorArgs = ['cuenta_liquida_id', 'meta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <option value="">Selecciona cuenta</option>
                        <?php $__currentLoopData = $cuentasOperativas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuenta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cuenta->id); ?>" <?php if($oldMeta && old('cuenta_liquida_id') == $cuenta->id): echo 'selected'; endif; ?>><?php echo e($cuenta->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <small class="text-secondary">Se crea un bolsillo dedicado; no se usa la cuenta operativa como destino.</small>
                    <?php echo $__env->make('layouts.partials.field-error', ['name' => 'cuenta_liquida_id', 'bag' => 'meta'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="row g-3">
                    <div class="col-6">
                        <label class="form-label" for="prioridad">Prioridad</label>
                        <select id="prioridad" name="prioridad" class="form-select form-select-lg <?php $__errorArgs = ['prioridad', 'meta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                            <?php $__currentLoopData = ['alta'=>'Alta','media'=>'Media','baja'=>'Baja']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v=>$t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($v); ?>" <?php if(($oldMeta ? old('prioridad', 'media') : 'media') === $v): echo 'selected'; endif; ?>><?php echo e($t); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php echo $__env->make('layouts.partials.field-error', ['name' => 'prioridad', 'bag' => 'meta'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="col-6">
                        <label class="form-label" for="estado">Estado</label>
                        <select id="estado" name="estado" class="form-select form-select-lg <?php $__errorArgs = ['estado', 'meta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                            <?php $__currentLoopData = ['activa'=>'Activa','pausada'=>'Pausada','cumplida'=>'Cumplida','cancelada'=>'Cancelada']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v=>$t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($v); ?>" <?php if(($oldMeta ? old('estado', 'activa') : 'activa') === $v): echo 'selected'; endif; ?>><?php echo e($t); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php echo $__env->make('layouts.partials.field-error', ['name' => 'estado', 'bag' => 'meta'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </section>

            <div class="form-actions">
                <button class="btn btn-primary btn-lg w-100" type="submit">Crear meta</button>
            </div>
        </form>
    <?php else: ?>
        <?php if($metas->isNotEmpty() && $cuentasOperativas->isNotEmpty()): ?>
        <form method="POST" action="<?php echo e(route('app.metas.aportes.store')); ?>" class="dash-card form-panel" novalidate>
            <?php echo csrf_field(); ?>
            <div class="form-section__head">
                <p class="form-section__eyebrow">Movimiento</p>
                <h2 class="form-section__title">Registrar aporte</h2>
            </div>
            <?php echo $__env->make('layouts.partials.form-errors', ['bag' => 'aporte'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="money-hero">
                <label class="form-label" for="monto_aporte">Monto</label>
                <input id="monto_aporte" name="monto" data-miles inputmode="decimal" value="<?php echo e($oldAporte ? old('monto') : ''); ?>" class="form-control form-control-lg <?php $__errorArgs = ['monto', 'aporte'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="0" required>
                <?php echo $__env->make('layouts.partials.field-error', ['name' => 'monto', 'bag' => 'aporte'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>

            <section class="form-section">
                <div>
                    <label class="form-label" for="meta_ahorro_id">Meta</label>
                    <select id="meta_ahorro_id" name="meta_ahorro_id" class="form-select form-select-lg <?php $__errorArgs = ['meta_ahorro_id', 'aporte'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <option value="">Selecciona una meta</option>
                        <?php $__currentLoopData = $metas->where('estado', '!=', 'cancelada'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($meta->id); ?>" <?php if($oldAporte && old('meta_ahorro_id') == $meta->id): echo 'selected'; endif; ?>><?php echo e($meta->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php echo $__env->make('layouts.partials.field-error', ['name' => 'meta_ahorro_id', 'bag' => 'aporte'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div>
                    <label class="form-label" for="cuenta_origen_aporte">Sale de</label>
                    <select id="cuenta_origen_aporte" name="cuenta_liquida_id" class="form-select form-select-lg <?php $__errorArgs = ['cuenta_liquida_id', 'aporte'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                        <option value="">Cuenta operativa</option>
                        <?php $__currentLoopData = $cuentasOperativas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuenta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($cuenta->id); ?>" <?php if($oldAporte && old('cuenta_liquida_id') == $cuenta->id): echo 'selected'; endif; ?>><?php echo e($cuenta->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php echo $__env->make('layouts.partials.field-error', ['name' => 'cuenta_liquida_id', 'bag' => 'aporte'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div>
                    <label class="form-label" for="fecha_aporte">Fecha</label>
                    <input id="fecha_aporte" name="fecha" type="date" value="<?php echo e($oldAporte ? old('fecha', now()->toDateString()) : now()->toDateString()); ?>" class="form-control form-control-lg <?php $__errorArgs = ['fecha', 'aporte'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                    <?php echo $__env->make('layouts.partials.field-error', ['name' => 'fecha', 'bag' => 'aporte'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </section>

            <div class="form-actions">
                <button class="btn btn-primary btn-lg w-100" type="submit">Contabilizar aporte</button>
            </div>
        </form>
        <?php elseif($metas->isNotEmpty()): ?>
            <div class="alert alert-light empty-state">
                Para aportar necesitas una cuenta operativa (no bolsillo) con saldo.
                <a href="<?php echo e(route('app.cuentas.create')); ?>">Crear cuenta</a>.
            </div>
        <?php else: ?>
            <div class="alert alert-light empty-state">Crea una meta primero para poder aportar.</div>
        <?php endif; ?>
    <?php endif; ?>

    <div class="list-block">
        <div class="list-block__head">
            <h2>Tus metas</h2>
            <span><?php echo e($metas->count()); ?></span>
        </div>
        <div class="card-stack">
        <?php $__empty_1 = true; $__currentLoopData = $metas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <article class="account-card">
            <div class="account-card__main">
                <div class="account-card__icon"><?php echo $__env->make('layouts.partials.icon', ['name' => 'piggy-bank', 'class' => 'ui-icon ui-icon--sm'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                <div class="account-card__body">
                    <div class="account-card__head">
                        <div class="account-card__title">
                            <h2><?php echo e($meta->nombre); ?></h2>
                            <small><?php echo e(ucfirst($meta->prioridad)); ?> · <?php echo e(ucfirst($meta->estado)); ?><?php if($meta->cuentaLiquida): ?> · <?php echo e($meta->cuentaLiquida->nombre); ?><?php endif; ?></small>
                        </div>
                        <strong class="account-card__amount"><?php echo e($meta->porcentaje_completado); ?>%</strong>
                    </div>
                    <div class="progress progress--thin mt-3"><div class="progress-bar" style="width: <?php echo e(min(100, $meta->porcentaje_completado)); ?>%"></div></div>
                    <div class="small text-secondary mt-2">Avance <?php echo \App\Support\Dinero::formatear($meta->progreso_centavos); ?> de <?php echo \App\Support\Dinero::formatear($meta->objetivo_centavos); ?> · Plan/mes: <?php echo \App\Support\Dinero::formatear($meta->aporte_mensual_centavos); ?></div>
                    <div class="small text-secondary">Cumplimiento estimado: <?php echo e($meta->fecha_estimada_cumplimiento ? \Carbon\Carbon::parse($meta->fecha_estimada_cumplimiento)->format('d/m/Y') : 'sin fecha (define un ahorro mensual)'); ?></div>
                </div>
            </div>
        </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="alert alert-light empty-state">Aún no tienes metas de ahorro.</div>
        <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', [
    'title' => 'Metas de ahorro',
    'heading' => 'Mis metas',
    'subtitle' => 'El avance solo crece con aportes contabilizados al bolsillo de la meta.',
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/angelpenaloza/Documents/GitHub/finanzas/resources/views/metas/index.blade.php ENDPATH**/ ?>